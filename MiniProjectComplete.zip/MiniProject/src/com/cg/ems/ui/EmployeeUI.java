package com.cg.ems.ui;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Scanner;






import org.apache.log4j.Logger;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmployeeService;

public class EmployeeUI {
	 static Logger log = Logger.getRootLogger();

	@SuppressWarnings({ "null", "resource" })
	public static void main(String[] args) throws EmployeeException {
		int n=0;
		int m=0;
        //creating a bean class object
		EmployeeBean beanOB = new EmployeeBean();
		//creating array lists for various methods
		ArrayList<EmployeeBean> allrecords = new ArrayList<EmployeeBean>();
		ArrayList<EmployeeBean> searchemp = new ArrayList<EmployeeBean>();
		ArrayList<EmployeeBean> leavedetail = new ArrayList<EmployeeBean>();
		ArrayList<EmployeeBean> seekLeave = new ArrayList<EmployeeBean>();
		
		//creating scanner class object
		Scanner scannerOB = new Scanner(System.in);
		//creating an object of service class
		EmployeeService serviceOB = new EmployeeService();
		int storedStatus=0;
		int checkleavevalue;
		
		//entering the UI
	    System.out.println("WELCOME TO EMPLOYEE MAINTENANCE SYSTEM");
	    System.out.println("--------------------------------------");
	    //making user entering the username
	    System.out.println("Enter your UserName");
	    //making bean class object for login process
	    EmployeeBean beanOB0 = new EmployeeBean();
		//scanning the user's input
	    do{String UserName = scannerOB.next();
		//making user entering the password
		System.out.println("Enter your Password");
		//scanning the password
		String Password = scannerOB.next();
        //calling the method through service class for loging in
		beanOB0=serviceOB.getaccess(UserName,Password);
		//if username has 'admin' type in user_master table, following part will execute
		if(beanOB0.getUserType() != null && beanOB0.getUserType().equals("admin"))
		{
            //Entering the admin part, now get services of admin
			System.out.println("WELCOME TO THE ADMIN WORLD..");
			System.out.println("----------------------------");
			System.out.println("1. Add Employee Details\n2. Modify Employee Details\n3. Display Employee Details\n4. Exit");
			System.out.println("------------------------");
			System.out.println("Choose one of the options");
			log.info("Into Admin World");
			int enter=0;
			//taking input from the user
			do{ 
				String value1 = scannerOB.next();
			
			
			switch (value1) {
			case "1":
				
				    
					System.out.println("Enter Employee's First name");
					String EmpFirstname="";
					do{String EmpAddress1="";
						 EmpFirstname= scannerOB.next();
						 //this if is validating the first name, it should start from capital letter
						if(EmpFirstname.matches("[A-Z]{1}[A-Za-z]*"))
							
						{
							System.out.println("Enter Employee's Last name");
							String EmpLastname="";
							do{
								 EmpLastname= scannerOB.next();
								 ////this if is validating the last name, it should start from capital letter
								if(EmpLastname.matches("[A-Z]{1}[A-Za-z]*"))
							    {
									System.out.println("Enter Employee's Date of Birth in YYYY-MM-DD format");
								Date EmpDOB1=null;
								boolean flag2=false;
								//ensuring that the date is in valid format	
								do{
										try{String EmpDOB= scannerOB.next();
								         flag2=false;
								      EmpDOB1= Date.valueOf(EmpDOB);
								      
								      }
									catch(IllegalArgumentException e1)
									{   log.error("Error in date value");
										flag2=true;
										System.err.println("Invalid format!! Please enter again");}}
									while(flag2==true);
								
								
									System.out.println("Enter Employee's Date of Joining in YYYY-MM-DD format");
								Date EmpDOJ1 = null;
								boolean flag1=false;
								////ensuring that the date is in valid format
								do{
									try{String EmpDOJ= scannerOB.next();
								         flag1=false;
								
								EmpDOJ1 = Date.valueOf(EmpDOJ);}
								catch(IllegalArgumentException e)
								{    log.error("Error in date value");
									flag1=true;
									System.err.println("Invalid Format!! Please enter again");
								}}
								while(flag1==true);
								
								System.out.println("Enter Employee's Grade");
								String Grade = "";
								
								do{
									 Grade= scannerOB.next();
									 //this if is for ensuring that the grade must be from M1 M2 M3 M4 M5 M6 M7
									if(Grade.equals("M1") || Grade.equals("M2") || Grade.equals("M3") ||Grade.equals("M4") ||Grade.equals("M5") ||Grade.equals("M6") ||Grade.equals("M7") )
									{
									System.out.println("Enter Employee's Department Name");
									System.out.println("1.Sales\n2.Software Engineering\n3.Consultancy");
									String dept=scannerOB.next();
									//to choose department between Sales, consultancy, and SE
									switch (dept) {
									case "1":
										dept="Sales";
										
										break;
									case "2":
										dept="Software Engineering";
										break;
									case "3":
										dept="Consultancy";
										break;
									default: System.err.println("please choose appropriate input");
									 log.error("wrong input");
										break;
									}
									
									System.out.println("Enter Employee's Designation");
									String Designation="";
									do{
									 Designation= scannerOB.next();
										//validating designation to be of maximum 50 characters
										if(Designation.matches("[A-Za-z]{1,50}"))
										{System.out.println("Enter Employee's Basic Salary");
										int EmpBasic=0;
										boolean flag=false;
										//for grade M7, salary shoud be between 10000 and 15000
										if(Grade.equals("M7"))
		                                    { 
											do{
												EmpBasic= scannerOB.nextInt();
												if(EmpBasic>10000 && EmpBasic<15000)
												{
													flag=true;
													System.out.println("Enter Employee's Gender");
													 System.out.println("Type M for Male and F for female");
												}
												else
												{
													 log.error("Basic Salary error");
													System.err.println("Enter valid basic.");
												}
												
											}while(flag==false);
											
		                                    }
										////for grade M7, salary shoud be between 15000 and 20000
										if(Grade.equals("M6"))
	                                    { 
										do{
											EmpBasic= scannerOB.nextInt();
											if(EmpBasic>15000 && EmpBasic<20001)
											{
												flag=true;
												System.out.println("Enter Employee's Gender");
												 System.out.println("Type M for Male and F for female");
											}
											else
											{
												 log.error("Basic Salary error");
												System.err.println("Enter valid basic.");
											}
											
										}while(flag==false);
										
	                                    }
										////for grade M5, salary shoud be between 20000 and 25000			 
										if(Grade.equals("M5"))
	                                    { 
										do{
											EmpBasic= scannerOB.nextInt();
											if(EmpBasic>20000 && EmpBasic<25001)
											{
												flag=true;
												System.out.println("Enter Employee's Gender");
												 System.out.println("Type M for Male and F for female");
											}
											else
											{
												 log.error("Basic Salary error");
												System.err.println("Enter valid basic.");
											}
											
										}while(flag==false);
										
	                                    }
										////for grade M4, salary shoud be between 25000 and 30000
										if(Grade.equals("M4"))
	                                    { 
										do{
											EmpBasic= scannerOB.nextInt();
											if(EmpBasic>25000 && EmpBasic<30001)
											{
												flag=true;
												System.out.println("Enter Employee's Gender");
												 System.out.println("Type M for Male and F for female");
											}
											else
											{
												 log.error("Basic Salary error");
												System.err.println("Enter valid basic.");
											}
											
										}while(flag==false);
										
	                                    }
													 
										if(Grade.equals("M3"))
	                                    { 
										do{
											EmpBasic= scannerOB.nextInt();
											if(EmpBasic>30000 && EmpBasic<35001)
											{
												flag=true;
												System.out.println("Enter Employee's Gender");
												 System.out.println("Type M for Male and F for female");
											}
											else
											{
												 log.error("Basic Salary error");
												System.err.println("Enter valid basic.");
											}
											
										}while(flag==false);
										
	                                    }
													
										if(Grade.equals("M2"))
	                                    { 
										do{
											EmpBasic= scannerOB.nextInt();
											if(EmpBasic>35000 && EmpBasic<40001)
											{
												flag=true;
												System.out.println("Enter Employee's Gender");
												 System.out.println("Type M for Male and F for female");
											}
											else
											{
												 log.error("Basic Salary error");
												System.err.println("Enter valid basic.");
											}
											
										}while(flag==false);
										
	                                    }
													 
													 
										if(Grade.equals("M1"))
	                                    { 
										do{
											EmpBasic= scannerOB.nextInt();
											if(EmpBasic>40000 && EmpBasic<50001)
											{
												flag=true;
												System.out.println("Enter Employee's Gender");
												 System.out.println("Type M for Male and F for female");
											}
											else
											{
												 log.error("Basic Salary error");
												System.err.println("Enter valid basic.");
											}
											
										}while(flag==false);
										
	                                    }
													
													 String Gender="";
													 do{
											Gender= scannerOB.next();
											if(Gender.equals("M") || Gender.equals("F"))
										    {System.out.println("Enter Employee's Marital Status");
										    String MarStatus="";
										    do{
												MarStatus= scannerOB.next();
												if(MarStatus.equals("Single") || MarStatus.equals("Married") || MarStatus.equals("Widowed") || MarStatus.equals("Seperated") || MarStatus.equals("Divorced"))
												{System.out.println("Enter Employee's Address");
												String EmpAddress="";
												do{EmpAddress= scannerOB.nextLine();
												if(EmpAddress.matches("[a-zA-Z0-9,\\s]+"))
												System.out.println("Enter Employee's contact Number");
												else {System.err.println("Address' format is not correct");
												 log.error("Error in address");}
												}while(!EmpAddress.matches("[a-zA-Z0-9,\\s]+"));
												String EmpContact= scannerOB.next();
												System.out.println("Enter Employee's Manager Code");
												int EmpMgr= scannerOB.nextInt();
												System.out.println("Enter Employee's UserName");
												String UserN= scannerOB.next();
												
												
												
												try{ 
												//now setting all the scanned values to the bean class
												beanOB.setEmpFirstName(EmpFirstname);
												
												beanOB.setEmpLastName(EmpLastname);
												
												beanOB.setEmpDOJ(EmpDOJ1);
												
												beanOB.setEmpDOB(EmpDOB1);
												
												beanOB.setDeptName(dept);
												
												beanOB.setEmpGrade(Grade);
												
												beanOB.setEmpDesignation(Designation);
												
												beanOB.setEmpBasic(EmpBasic);
												beanOB.setEmpGender(Gender);
												
												beanOB.setEmpMaritalStatus(MarStatus);
												
												beanOB.setEmpAddress(EmpAddress);
												
												beanOB.setEmpContact(EmpContact);
												
												beanOB.setMgrID(EmpMgr);
												beanOB.setUserName(UserN);
												
												n=serviceOB.addEmployeeDetails(beanOB);
												System.err.println(n + " DATA UPDATED SUCCESFULLY!!"); 
												}
												catch(EmployeeException e)
												{  log.error("Error in adding details");
													System.out.println(e);}}
												else
													{System.err.println("Please enter valid Marital Status");
													log.error("Marital Status error");
													}
											}while(!MarStatus.equals("Single") || MarStatus.equals("Married") || MarStatus.equals("Widowed") || MarStatus.equals("Seperated") || MarStatus.equals("Divorced"));
											
												}
											else
												{ System.err.println("Please enter valid Gender");
												log.error("Gender error");
												}
										}while(!Gender.equals("M") || Gender.equals("F"));
										
											}
										else
											{System.err.println("Please enter valid Designation");
											log.error("Designation error");
											}
									}while(!Designation.matches("[A-Za-z]{1,50}"));
									
										}
									else
									{
										System.err.println("Please enter valid Grade");
										log.error("Grade error");
									}
								}while(!Grade.equals("M1") || Grade.equals("M2") || Grade.equals("M3") || Grade.equals("M4") || Grade.equals("M5") || Grade.equals("M6"));
								
								}
								
								else
								{
									System.err.println("Please enter valid Last Name");
									log.error("Last Name error");
								}
							}while(!EmpLastname.matches("[A-Z]{1}[A-Za-z]*"));
							
						}					
						else
						{
							System.err.println("Please enter valid First Name");
							log.error("First Name error");
						}
					}while(!EmpFirstname.matches("[A-Z]{1}[A-Za-z]*"));
					
				
				break;
				
				
			case "2":
				//modification selection starts, user will enter employee ID whose modification needs to be done
				System.out.println("Enter Employee ID");
				System.out.println("------------------------");
				do{
					String ModID = scannerOB.next();
					//calling the method for modification
					storedStatus = serviceOB.searchModID(ModID);
					if(storedStatus==1)
						//user will get options for modification fields
					{beanOB.setEmpID(ModID);
					System.out.println("Select the fields you want to modify");
					System.out.println("------------------------");
					System.out.println("1.Employee's First Name\n2.Employee's Last Name\n3.Employee's Department\n4.Employee's Grade\n5.Employees's Designation\n6.Employees's Basic Salary\n7.Employees's Marital status\n8.Employee's Address\n9.Employee's Contact Number");
				
					 int flag=0;
					 String value2 ="";
					do{
						 value2 = scannerOB.next();
						switch (value2) {
						//user will enter the values according to his choice
						case "1": System.out.println("Enter Employee's new first name");
						flag=1;
						String newFName="";
						do{
							newFName = scannerOB.next();
							
							if(newFName.matches("[A-Z]{1}[A-Za-z]*"))
							{beanOB.setEmpFirstName(newFName);
							
							}else
								{System.err.println("Name not in valid format!! Please enter again");
								 log.error("Error in name value");}
						
						}while(!newFName.matches("[A-Z]{1}[A-Za-z]*"));
						break;
						
						case "2": System.out.println("Enter Employee's new last name");
						flag=1;
						String newLName = "";
						do{
							 newLName = scannerOB.next();
							if(newLName.matches("[A-Z]{1}[A-Za-z]*"))
							beanOB.setEmpLastName(newLName);
							else {System.err.println("Not in valid format!! Please enter again");
							 log.error("Error in name value");}
						}while(!newLName.matches("[A-Z]{1}[A-Za-z]*"));
						
					    break;
						case "3": System.out.println("Enter Employee's new Department");
						flag=1;
						String newDept = scannerOB.next();
						beanOB.setDeptName(newDept);
						break;
						case "4": System.out.println("Enter Employee's new Grade");
						flag=1;
						String newGrade = "";
						do{
							//new grade must matches the basic set of grades
							newGrade = scannerOB.next();
							if(newGrade.matches("M1") && newGrade.matches("M2")  && newGrade.matches("M3")  && newGrade.matches("M4")  && newGrade.matches("M5")  && newGrade.matches("M6")  && newGrade.matches("M7"))
							beanOB.setEmpGrade(newGrade);
							else {System.err.println("Not a valid Grade!! Please enter again");
							 log.error("Error in grade value");}
						}while(!newGrade.matches("M1") && newGrade.matches("M2")  && newGrade.matches("M3")  && newGrade.matches("M4")  && newGrade.matches("M5")  && newGrade.matches("M6")  && newGrade.matches("M7"));
						
						break;
						case "5": System.out.println("Enter Employee's new Designation");
						flag=1;
						String newDesignation = scannerOB.next();
						beanOB.setEmpDesignation(newDesignation);
						break;
						case "6": System.out.println("Enter Employee's new Basic Salary");
						flag=1;
						int newSalary = scannerOB.nextInt();
						beanOB.setEmpBasic(newSalary);
						break;
						case "7": System.out.println("Enter Employee's new Marital Status");
						flag=1;
						String newMStatus = "";
						do{
							//new status must matches the basic set of status
							 newMStatus = scannerOB.next();
							if(newMStatus.matches("Single") && newMStatus.matches("Married") && newMStatus.matches("Divorced") && newMStatus.matches("Widowed") && newMStatus.matches("Seperated") )
							beanOB.setEmpMaritalStatus(newMStatus);
							else {System.err.println("Not a valid status!! Please enter again");
							 log.error("Error in status value");}
						}while(!newMStatus.matches("Single") && newMStatus.matches("Married") && newMStatus.matches("Divorced") && newMStatus.matches("Widowed") && newMStatus.matches("Seperated"));
						
						break;
						case "8": System.out.println("Enter Employee's new Address");
						flag=1;
						String newAddress = scannerOB.next();
						beanOB.setEmpAddress(newAddress);
						break;
						case "9": System.out.println("Enter Employee's new contact number");
						flag=1;
						String newContact ="";
						do{
							newContact = scannerOB.next();
						    if(newContact.matches("[7-9]{1}[0-9]{9}"))
						    	beanOB.setEmpContact(newContact);
						    else {System.err.println("Not a valid phone number!! Enter again");
						    log.error("Error in phone number value");}
						}while(!newContact.matches("[7-9]{1}[0-9]{9}"));
						
						
						break;
					    default: System.err.println("Please select valid option");
					    log.error("Wrong option selected");
							break;
						}}while(flag==0);
					
					
						EmployeeBean beanOB2 = new EmployeeBean();
						//caling the method for updating the employees
						int s=serviceOB.updateEmployees(beanOB,value2);
						
						System.out.println("Record updated succesfully!!");
					
					}
					
					else {System.err.println("NO SUCH EMP ID FOUND!!! Enter again");
					 log.error("No record found");}
				}while(storedStatus==0);
				
				break;
				
				
			
			case "3":
			    	
				EmployeeBean beanOB4 = new EmployeeBean();
				allrecords=serviceOB.displayAll();
				if(allrecords.isEmpty())
					System.err.println("No records there");
				else {  log.info("Displaying records");
				System.out.println("Employee ID || Firstname || LastName || DateOfBirth || DateOfJoining || DepartmentID || Grade || Designation || Salary || Gender || Marital Status || HomeAddress                    || ContactNumber || ManagerID");
				for (EmployeeBean bean : allrecords) {
					
					System.out.println(bean.getEmpID()+"         "+bean.getEmpFirstName()+"       "+bean.getEmpLastName()+"        "+bean.getEmpDOB()+"        "+bean.getEmpDOJ()+"         "+bean.getDeptID()+"           "+bean.getEmpGrade()+"      "+bean.getEmpDesignation()+"      "+bean.getEmpBasic()+"      "+bean.getEmpGender()+"       "+bean.getEmpMaritalStatus()+"            "+bean.getEmpAddress()+"                              "+bean.getEmpContact()+"         "+bean.getMgrID());
				}}
				break;
			case "4": System.exit(0);
			break;
			default: System.err.println("Invalid INPUT!! Enter again");
			 log.error("wrong input");
			enter=1;
			break;
			}}while(enter==1);}
			else if(beanOB0.getUserType() != null && beanOB0.getUserType().equals("employee"))
		{
				//if username matches the 'employee' type, it will come here
			System.out.println("WELCOME TO THE EMPLOYEE WORLD");
			System.out.println("-----------------------------");
			System.out.println("1. Search for an employee\n2. Leave Maintenance System\n3. Exit");
			System.out.println("------------------------");
			System.out.println("Choose one of the options");
			int enter2=0;
			do{String value3 = scannerOB.next();
			switch (value3) {
			case "1":
				String searchID="";
				String searchFName="";
				String searchLName="";
				String searchDept="";
				String searchGrade="";
				String searchMStatus="";
				System.out.println("Select the field to check\n");
				System.out.println("----------------------------");
				System.out.println("1.EmployeeID");
				System.out.println("2.Employee's First Name");
				System.out.println("3.Employee's Last Name");
				System.out.println("4.Employee's Grade");
				System.out.println("5.Employee's Marital Status");
				int enter3=0;
				do{
					String value4 = scannerOB.next();
				
				EmployeeBean beanOBJ6 = new EmployeeBean();
				switch (value4) {
				//accordingly user will enter the field through which he want to search
				case "1":System.out.println("Enter Employee ID");
				System.out.println("------------------------");
				int searchflag=0;
				do{
				 searchID = scannerOB.next();
				 //validation on employee ID to scan in correct form
				 if(searchID.matches("[1-9]{1}[0-9]{5}"))
				 //calling the method if ID is correct
	                {searchemp=serviceOB.searchEmployees(searchID, searchFName, searchLName, searchDept, searchGrade, searchMStatus);
	                
	                log.info("searching through ID"); 
	                for (EmployeeBean beanOB6 : searchemp) { 
	                	 System.out.println("Employee's ID is " + beanOB6.getEmpID() );
					 System.out.println("Employee's first name is " + beanOB6.getEmpFirstName() );
					 System.out.println("Employee's last name is " + beanOB6.getEmpLastName() );
					 System.out.println("Employee's grade is " + beanOB6.getEmpGrade() );
					 System.out.println("Employee's designation is " + beanOB6.getEmpDesignation() );
						
					}
	              }
				 else {searchflag=1;
					 System.err.println("NO RECORDS FOUND!!! Enter again");
					 log.error("No records found");
						 }
				 log.error("Error in displaying employees");
				}while(searchflag==1);
                
					 break;
				case "2":System.out.println("Enter Employee's First Name");
				System.out.println("------------------------");
				int searchF=0;
				do{searchFName = scannerOB.next();
				//searching through employees 
				searchemp=serviceOB.searchEmployees(searchID, searchFName, searchLName, searchDept, searchGrade, searchMStatus);
				if(searchemp.isEmpty()){
					searchF=1;
					System.err.println("NO SUCH RECORDS FOUND!!! Enter again ");
					 log.error("No records found");
				}else{log.info("searching through first name");
				for (EmployeeBean beanOB6 : searchemp) { 
	               	 System.out.println("Employee's ID is " + beanOB6.getEmpID() );
					 System.out.println("Employee's first name is " + beanOB6.getEmpFirstName() );
					 System.out.println("Employee's last name is " + beanOB6.getEmpLastName() );
					 System.out.println("Employee's grade is " + beanOB6.getEmpGrade() );
					 System.out.println("Employee's designation is " + beanOB6.getEmpDesignation() );
					 System.out.println("-----------------------------");
					}
	               } break;
				}while(searchF==1);
				
				case "3":System.out.println("Enter Employee's Last Name");
				System.out.println("------------------------");
				int searchL=0; 
				//calling the method through last name
				do{searchLName = scannerOB.next();
				 searchemp=serviceOB.searchEmployees(searchID, searchFName, searchLName, searchDept, searchGrade, searchMStatus);
				if(searchemp.isEmpty()){
					searchL=1;
					System.err.println("NO SUCH RECORDS FOUND!!!\nEnter again");
					 log.error("No records found");
				}
				else{log.info("searching through last name");
				 for (EmployeeBean beanOB6 : searchemp) { 
                	 System.out.println("Employee's ID is " + beanOB6.getEmpID() );
				 System.out.println("Employee's first name is " + beanOB6.getEmpFirstName() );
				 System.out.println("Employee's last name is " + beanOB6.getEmpLastName() );
				 System.out.println("Employee's grade is " + beanOB6.getEmpGrade() );
				 System.out.println("Employee's designation is " + beanOB6.getEmpDesignation() );
				 System.out.println("-----------------------------");
				}}
				 }while(searchL==1);
                break;
			    
				case "4":System.out.println("Enter Employee's Grade");
				System.out.println("------------------------");
				int searchG=0;
				do{ searchGrade = scannerOB.next();
				//calling the method through grade
				 searchemp=serviceOB.searchEmployees(searchID, searchFName, searchLName, searchDept, searchGrade, searchMStatus);
				 if(searchemp.isEmpty()){ searchG=1;
					 System.err.println("NO SUCH RECORDS FOUND!!! Enter again");
					 log.error("No records found");}
				
				 else{log.info("searching through Grade");
				 for (EmployeeBean beanOB6 : searchemp) { 
                	 System.out.println("Employee's ID is " + beanOB6.getEmpID() );
				 System.out.println("Employee's first name is " + beanOB6.getEmpFirstName() );
				 System.out.println("Employee's last name is " + beanOB6.getEmpLastName() );
				 System.out.println("Employee's grade is " + beanOB6.getEmpGrade() );
				 System.out.println("Employee's designation is " + beanOB6.getEmpDesignation() );
				 System.out.println("-----------------------------");
				}}
				}while(searchG==1);
                break;
				case "5":System.out.println("Enter Employee's Marital Status");
				System.out.println("------------------------");
				int searchM=0;
				do{
					 searchMStatus = scannerOB.next();
					 searchemp=serviceOB.searchEmployees(searchID, searchFName, searchLName, searchDept, searchGrade, searchMStatus);
					 if(searchemp.isEmpty()){
						 log.error("No records found");	
					 searchM=1;
						 System.err.println("NO SUCH RECORDS FOUND!!! Enter again");}
				
				 else{log.info("searching through Marital Status");
				 for (EmployeeBean beanOB6 : searchemp) { 
                	 System.out.println("Employee's ID is " + beanOB6.getEmpID() );
				 System.out.println("Employee's first name is " + beanOB6.getEmpFirstName() );
				 System.out.println("Employee's last name is " + beanOB6.getEmpLastName() );
				 System.out.println("Employee's grade is " + beanOB6.getEmpGrade() );
				 System.out.println("Employee's designation is " + beanOB6.getEmpDesignation() );
					System.out.println("-----------------------------");
				}}
				  
				}while(searchM==1);
				 break;
                
                default: System.err.println("Input is invalid!!! Please enter again");
                log.error("wrong input");
                enter3=1;
					break;
				
				}}while(enter3==1);
			case "2": 
				//checking whether the username is manager or just a normal employee
				int status=serviceOB.EmpORMgr(UserName); 
				EmployeeBean beanOB6 = new EmployeeBean();
				if(status==0)
					//if a normal employee, this method will run
					{ System.out.println("1.Apply for leave\n2.Leaves History");
					String leave1 = scannerOB.next();
					switch (leave1) {
					case "1":System.out.println("Date from which you want leave");
					System.out.println("Enter in YYYY-MM_DD format");
					System.out.println("----------------------------");
					
					int leaveFromFlag=0;
					Date LeaveFrom1=null;
					//to take date in a correct format
					do{ String lFrom = scannerOB.nextLine();
						String LeaveFrom= scannerOB.next();
					try{
					LeaveFrom1 = Date.valueOf(LeaveFrom);}
					catch(Exception e)
					{leaveFromFlag=1;
						System.out.println("Please enter in valid format");
						 log.error("wrong format");}
					}while(leaveFromFlag==1);
					System.out.println("Number of days of leave you want");
					int NoOfDays = scannerOB.nextInt();
					storedStatus=0;
					System.out.println();
					//calling the method for applying leave
					storedStatus=serviceOB.applyLeave(UserName, LeaveFrom1, NoOfDays);
					if(storedStatus==1)
						{System.out.println(storedStatus + " DATA UPDATED");
					System.out.println("Applied for leave");
					System.exit(0);}
					else
						//if leave balance is less than the no of leaves applied
						{System.err.println("YOU DO NOT HAVE MUCH LEAVES LEFT");
						System.exit(0);}
					break;
					case "2": 
						leavedetail=serviceOB.leaveleft(UserName);
						if(leavedetail.isEmpty())
							//if the list of leave history is emplty
						{System.err.println("List is empty");
						System.exit(0);}
						else{
						System.out.println("LEAVE ID  ||  EMP ID || LEAVE BALANCE || DATE FROM || DATE TO   || STATUS ||");
						for (EmployeeBean beanOB61: leavedetail)
							
							System.out.println(beanOB61.getLeaveID() + "         " + beanOB61.getEmpID() + "         "  + beanOB61.getLeaveBalance() + "            "  + beanOB61.getDateFrom() + "  "  + beanOB61.getDateTo() + "   "  + beanOB61.getStatus() );
						break;}

					default: 
						break;
					}
					
					}
				if(status==1) 
					//if the username is of manager type, it will enter here 
					{System.out.println("1.Ask for leave\n2.View leave details\n3.Approve or reject  leave");
					int ManagerWhile=0;
					do{
						String value = scannerOB.next();
					
					switch (value) {
					//manager applying for leave
					case "1":System.out.println("Date from which you want leave");
					System.out.println("------------------------");
					System.out.println("Enter in YYYY-MM-DD");
					System.out.println("------------------------");
					Date LeaveFrom1=null;
					int leaveFromFlag=0;
					do{String LeaveFrom= scannerOB.next();
					try{LeaveFrom1 = Date.valueOf(LeaveFrom);}
					catch(Exception e)
					{ leaveFromFlag=1;
						System.err.println("Date is not in valid format!! Enter again");
						 log.error("wrong format");}
					}while( leaveFromFlag==1);
					System.out.println("Number of days of leave you want");
					int NoOfDays = scannerOB.nextInt();
					storedStatus=0;
					System.out.println();
					//making manager to apply for leave
					storedStatus=serviceOB.applyLeave(UserName, LeaveFrom1, NoOfDays);
					if(storedStatus==1)
						{System.out.println(storedStatus + " DATA UPDATED");
					System.out.println("Leave applied");}
					else
						{System.err.println("YOU DO NOT HAVE MUCH LEAVES LEFT");}
						
						break;
					case "2": leavedetail=serviceOB.leaveleft(UserName);
					if(leavedetail.isEmpty())
							{System.err.println("List is empty");
							 log.error("Empty list");
					System.exit(0);}
					else {System.out.println("LEAVE ID  ||  EMP ID || LEAVE BALANCE || DATE FROM || DATE TO   || STATUS ||");
					for (EmployeeBean beanOB61: leavedetail)
						
						System.out.println(beanOB61.getLeaveID() + "         " + beanOB61.getEmpID() + "         "  + beanOB61.getLeaveBalance() + "            "  + beanOB61.getDateFrom() + "  "  + beanOB61.getDateTo() + "   "  + beanOB61.getStatus() );
					}break;
					case "3": System.out.println("Following are the employees who want leave");
					EmployeeBean beanOB7 = new EmployeeBean();
				
					seekLeave=serviceOB.wantsLeave(UserName);
					//if the list of employee's who want leave is empty
					if(seekLeave.isEmpty())
						{System.err.println("List is Empty");
						 log.error("Empty list");
						System.exit(0);}
					else {  log.info("Showing the values");
						System.out.println("LEAVE ID  ||  EMP ID || LEAVE BALANCE || DATE FROM || DATE TO   || STATUS ||");
					for (EmployeeBean beanOB62: seekLeave)
						
						
						{System.out.println(beanOB62.getLeaveID() + "         " + beanOB62.getEmpID() + "         "  + beanOB62.getLeaveBalance() + "            "  + beanOB62.getDateFrom() + "  "  + beanOB62.getDateTo() + "   "  + beanOB62.getStatus() );}
					System.out.println("---------------------------------------------------");
					System.out.println("Enter employee's ID whose leave you want to approve or reject");
					int norecord;
					 
					do{norecord=0;
						String ELID = scannerOB.next();
					
					System.out.println("----------------------------------");
					int LeaveIDerror;
					int ELID2=0;
					System.out.println("Enter the Leave ID also");
					BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
					
					do
					{
						try
						{
							ELID2 =Integer.parseInt( br.readLine());
							LeaveIDerror=0;
							//System.out.println("HELBE");
						}
						catch(Exception e)
						{  log.error("wrong input");
							LeaveIDerror=1;
							System.err.println("Enter value in valid format");
						
						}
					}while(LeaveIDerror==1);
					
						checkleavevalue=serviceOB.checkleave(ELID,ELID2);
					System.out.println(checkleavevalue);
					if(checkleavevalue==1)
						//now manager can allow or reject the leave using following switch case
						{System.out.println("Choose one of the following\n1.Approve\n2.Reject");
						 log.info("approving leave");
					String decision = scannerOB.next();
					switch (decision) {
					case "1":
						storedStatus=serviceOB.approveLeave(ELID, ELID2);
						System.out.println("----------------------------------");
						System.out.println("LEAVE APPROVED");
						System.exit(0);
						
						break;
					case "2":  log.info("rejecting leave");
						storedStatus=serviceOB.rejectLeave(ELID,ELID2);
						System.out.println("----------------------------------");
						System.out.println("LEAVE REJECTED");
						System.exit(0);
						break;
					default: System.err.println("Invalid input!!! Enter again");
					 log.error("wrong input");
						break;
					}} else {
						norecord=1;
						System.err.println("Enter valid EMP_ID and Leave_ID ");}
					}while(norecord==1);
					}break;
						
						

					default: ManagerWhile=1;
					 log.error("wrong input");
						System.err.println("Please select appropriate values");
						break;
					}}while(ManagerWhile==1);
					
					}
				
				break;
			case "3": System.exit(0);
			        break;

			default: System.err.println("Input is invalid!! Enter again");
			 log.error("invalid input");
			enter2=1;
				break;
			}}while(enter2==1);}
			else
			{
				 log.error("wrong credentials");
				 System.out.println("CREDENTIALS ARE INVALID");
			System.out.println("-----------------------");
			log.error("wrong credentials");
			System.out.println("Please enter your username again");
			}}
		
		while(!(beanOB0.getUserType() != null && beanOB0.getUserType().equals("admin")) || (beanOB0.getUserType() != null && beanOB0.getUserType().equals("employee")));
		
			scannerOB.close();
		
}
}
	
