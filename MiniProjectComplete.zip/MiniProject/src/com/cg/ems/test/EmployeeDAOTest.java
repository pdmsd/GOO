package com.cg.ems.test;

import static org.junit.Assert.*;

import java.sql.Date;

import org.junit.Test;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.dao.EmployeeDAO;
import com.cg.ems.dao.IEmployeeDAO;
import com.cg.ems.exception.EmployeeException;

public class EmployeeDAOTest {
	EmployeeBean bean = new EmployeeBean();
	IEmployeeDAO dao = new EmployeeDAO();

	@Test
	public void testGetaccess() throws EmployeeException {
		String userName = "piy26";
		String password = "scd20";
		assertEquals("employee",dao.getaccess(userName, password));
		
	}

	@Test
	public void testSearchModID() throws EmployeeException {
		String ModID = "100003";
		assertEquals("100003", dao.searchModID(ModID));
	}

	@Test
	public void testUpdateEmployees() throws EmployeeException {
		String value2="1";
		EmployeeBean beanOB = null;
		assertEquals("1", dao.updateEmployees(beanOB, value2));
	}

	@Test
	public void testAddEmployeeDetails() {
	}

	@Test
	public void testDisplayEmployeeDetailsUser() throws EmployeeException {
		String searchID="100003";
		assertEquals("100003", dao.displayEmployeeDetailsUser(searchID));
	}

	@Test
	public void testSearchEmployees() throws EmployeeException{
		String searchID="100003";
		String searchFName="Piyush";
		String searchLName="Dubey";
		String searchDept="Sales";
		String searchGrade="M1";
		String searchMStatus="Single";
         assertEquals(1, dao.searchEmployees(searchID, searchFName, searchLName, searchDept, searchGrade, searchMStatus));
	}

	@Test
	public void testDisplayEmployeeDetailsAdmin() throws EmployeeException {
          String searchID="100003";
       assertEquals("100003", dao.displayEmployeeDetailsAdmin(searchID));         
	}

	@Test
	public void testEmpORMgr() throws EmployeeException{
		String userName="utk";
		assertEquals("utk", dao.EmpORMgr(userName));
	}

	@Test
	public void testApplyLeave() throws EmployeeException {
		String userName="utk";
		Date leaveFrom1 = new Date(0, 0, 0);
		int noOfDays = 3;
      assertEquals(1, dao.applyLeave(userName, leaveFrom1, noOfDays));
	}

	@Test
	public void testLeaveleft() {

	}

	@Test
	public void testWantsLeave() {
		fail("Not yet implemented");
	}

	@Test
	public void testApproveLeave() throws EmployeeException {
    String ELID="100003";
    int ELID2=201;
	assertEquals(1, dao.approveLeave(ELID, ELID2));
	}

	@Test
	public void testRejectLeave() throws EmployeeException {
		 String ELID="100003";
		    int ELID2=201;
			assertEquals(1, dao.rejectLeave(ELID, ELID2));
	}

	@Test
	public void testCheckleave() throws EmployeeException {
		 String ELID="100003";
		    int ELID2=201;
			assertEquals(1, dao.checkleave(ELID, ELID2));
	}

}
