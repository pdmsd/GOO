package com.cg.ems.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.ems.bean.EmployeeBean;

public class EmployeeBeanTest {
	
	EmployeeBean bean= new EmployeeBean();
	EmployeeBeanTest test = new EmployeeBeanTest();

	@Test
	public void testGetUserID() {
		bean.setUserID("100003");
		assertEquals("100003", bean.getUserID());
	}

	@Test
	public void testGetUserName() {
		bean.setUserName("piyush");
		assertEquals("piyush", bean.getUserName());
	}

	@Test
	public void testGetUserPassword() {
        bean.setUserPassword("scd20");
        assertEquals("scd20", bean.getUserPassword());}

	@Test
	public void testGetUserType() {
         bean.setUserType("employee");
         assertEquals("employee", bean.getUserType());}

	@Test
	public void testGetDeptID() {
      bean.setDeptID(11);
      assertEquals(11, bean.getDeptID());}

	@Test
	public void testGetDeptName() {
     bean.setDeptName("Sales");
     assertEquals("Sales", bean.getDeptName());}

	@Test
	public void testGetEmpID() {
     bean.setEmpID("100003");
     assertEquals("100003", bean.getEmpID());}

	@Test
	public void testGetEmpFirstName() {
    bean.setEmpFirstName("Piyush");	
    assertEquals("Piyush", bean.getEmpFirstName());}

	@Test
	public void testGetEmpLastName() {
    bean.setEmpLastName("Dubey");
    assertEquals("Dubey", bean.getEmpLastName());}

	@Test
	public void testGetEmpDOB() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetEmpDOJ() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetEmpDeptID() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetEmpGrade() {
    bean.setEmpGrade("M1");
    assertEquals("M1", bean.getEmpGrade());}

	@Test
	public void testGetEmpDesignation() {
     bean.setEmpDesignation("ME");
     assertEquals("ME", bean.getEmpDesignation());}

	@Test
	public void testGetEmpBasic() {
    bean.setEmpBasic(40000);	
    assertEquals(40000, bean.getEmpBasic());}

	@Test
	public void testGetEmpGender() {
    bean.setEmpGender("M");
    assertEquals("M", bean.getEmpGender());}

	@Test
	public void testGetEmpMaritalStatus() {
    bean.setEmpMaritalStatus("Single");
    assertEquals("Single", bean.getEmpMaritalStatus());}

}
