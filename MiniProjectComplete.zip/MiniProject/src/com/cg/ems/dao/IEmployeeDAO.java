package com.cg.ems.dao;

import java.sql.Date;
import java.util.ArrayList;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.exception.EmployeeException;

public interface IEmployeeDAO {
	
	public abstract int addEmployeeDetails(EmployeeBean ob) throws EmployeeException;

	public EmployeeBean displayEmployeeDetailsUser(String searchID) throws EmployeeException;

	public abstract EmployeeBean displayEmployeeDetailsAdmin(String searchID) throws EmployeeException;
	
	public abstract ArrayList<EmployeeBean> searchEmployees(String searchID, String searchFName, String searchLName, String searchDept, String searchGrade, String searchMStatus) throws EmployeeException;

	public abstract ArrayList<EmployeeBean> displayAll() throws EmployeeException;

	public abstract EmployeeBean getaccess(String userName, String password) throws EmployeeException;

	public abstract int updateEmployees(EmployeeBean beanOB,String value2) throws EmployeeException;

	public abstract int EmpORMgr(String userName) throws EmployeeException;

	public abstract int applyLeave(String userName, Date leaveFrom1,int noOfDays) throws EmployeeException;
	
	public abstract int searchModID(String ModID) throws EmployeeException;

	public abstract ArrayList<EmployeeBean> leaveleft(String UserName) throws EmployeeException;
	
	public abstract ArrayList<EmployeeBean> wantsLeave(String UserName) throws EmployeeException;

	public abstract int approveLeave(String ELID, int ELID2) throws EmployeeException;

	public abstract int rejectLeave(String ELID, int ELID2) throws EmployeeException;

	public abstract int checkleave(String eLID, int eLID2) throws EmployeeException;

}
