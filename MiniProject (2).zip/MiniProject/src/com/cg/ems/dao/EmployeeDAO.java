package com.cg.ems.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.EmployeeUtil;

public class EmployeeDAO implements IEmployeeDAO {
	int storedStatus=0;
	
	//dbutil
	private Connection conn = null;
    EmployeeBean beanOB = new EmployeeBean();
	@Override
	public int addEmployeeDetails(EmployeeBean beanOB) throws EmployeeException {
		conn = EmployeeUtil.getConnection();
		/*System.out.println( beanOB.getEmpID());
		System.out.println(  beanOB.getEmpFirstName());
		System.out.println( beanOB.getEmpLastName());
		System.out.println(  beanOB.getEmpDOB());
		System.out.println( beanOB.getEmpDOJ());
		System.out.println( beanOB.getEmpDeptID());
		System.out.println(beanOB.getDeptName());
		System.out.println( beanOB.getEmpGrade());
		System.out.println( beanOB.getEmpDesignation());
		System.out.println( beanOB.getEmpBasic());
		System.out.println(beanOB.getEmpMaritalStatus());
		System.out.println(beanOB.getEmpAddress());
		System.out.println( beanOB.getEmpContact());
		System.out.println( beanOB.getMgrID());*/
		
		try{
		Statement stmt = conn.createStatement(); 
		
		
	PreparedStatement preparedStatement=conn.prepareStatement("INSERT INTO Employee values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
	preparedStatement.setString(1, beanOB.getEmpID());
	preparedStatement.setString(2, beanOB.getEmpFirstName());
	preparedStatement.setString(3, beanOB.getEmpLastName());
	preparedStatement.setString(4, beanOB.getEmpDOB());
	preparedStatement.setString(5, beanOB.getEmpDOJ());
	preparedStatement.setInt(6, beanOB.getEmpDeptID());
	preparedStatement.setString(7, beanOB.getDeptName());
	preparedStatement.setString(8, beanOB.getEmpGrade());
	preparedStatement.setString(9, beanOB.getEmpDesignation());
	preparedStatement.setInt(10, beanOB.getEmpBasic());
	preparedStatement.setString(11, beanOB.getEmpMaritalStatus());
	preparedStatement.setString(12, beanOB.getEmpAddress());
	preparedStatement.setString(13, beanOB.getEmpContact());
	preparedStatement.setInt(14, beanOB.getMgrID());
	
	storedStatus=preparedStatement.executeUpdate();
	if(storedStatus==1)
	{System.out.println("Inserted");}
	
		}
		catch(Exception e)
		{
			 throw new EmployeeException("problem DAO: "+e.getMessage());
		}
		
		
		
		
		//string query
		//prep stmt
		//stmt.setString(1,ob.getName())
		//return executeUpdate()
		
		
		return storedStatus;
	}
	@Override
	public int displayEmployeeDetailsAdmin(EmployeeBean beanOB) throws EmployeeException {
		try {
			
			Statement stmt1 = conn.createStatement(); 
			PreparedStatement preparedStatement=conn.prepareStatement("Select EMPID, EMP_FIRST_NAME, EMP_LAST_NAME, EMP_GRADE, EMP_DESIGN from Employee where EMPID=searchID");
		storedStatus=preparedStatement.executeUpdate();
		if(storedStatus==1)
		{System.out.println("Displayed");}}
		
			
			catch(Exception e)
			{
				 throw new EmployeeException("problem DAO: "+e.getMessage());
			
			
		
	}
		return storedStatus;}

}
