package com.cg.ems.dao;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.exception.EmployeeException;

public interface IEmployeeDAO {
	
	public abstract int addEmployeeDetails(EmployeeBean ob) throws EmployeeException;

	public abstract int displayEmployeeDetailsAdmin(EmployeeBean beanOB) throws EmployeeException;

}
