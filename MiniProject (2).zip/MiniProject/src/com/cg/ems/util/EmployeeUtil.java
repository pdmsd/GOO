package com.cg.ems.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.cg.ems.exception.EmployeeException;

public class EmployeeUtil {
	
	public static  Connection getConnection() throws EmployeeException
	{ Connection con=null;
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg226","training226");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new EmployeeException("Exception in Util");
		}
		return con;

}}
