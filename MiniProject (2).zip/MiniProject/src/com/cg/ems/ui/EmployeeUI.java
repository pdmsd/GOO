package com.cg.ems.ui;

import java.util.Scanner;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmployeeService;

public class EmployeeUI {

	@SuppressWarnings({ "null", "resource" })
	public static void main(String[] args) throws EmployeeException {
		int n=0;
 
		EmployeeBean beanOB = new EmployeeBean();
		Scanner scannerOB = new Scanner(System.in);
		EmployeeService serviceOB = new EmployeeService();
	
		System.out.println("Enter your UserName");
		String UserName = scannerOB.next();
		System.out.println("Enter your Password");
		String Password = scannerOB.next();
		
		switch (UserName) {
		case "admin":
			System.out.println("WELCOME TO THE ADMIN WORLD..");
			System.out.println("1. Add Employee Details 2. Modify Employee Details 3. Display Employee Details");
			int value1 = scannerOB.nextInt();
			switch (value1) {
			case 1:
				System.out.println("Enter the Employee ID");
				String EmpID= scannerOB.next();
				System.out.println("Enter Employee's First name");
				String EmpFirstname= scannerOB.next();
				System.out.println("Enter Employee's Last name");
				String EmpLastname= scannerOB.next();
				System.out.println("Enter Employee's Date of Joining");
				String EmpDOJ= scannerOB.next();
				System.out.println("Enter Employee's Date of Birth");
				String EmpDOB= scannerOB.next();
				System.out.println("Enter the Employee's Department ID");
				int EmpDeptID= scannerOB.nextInt();
				System.out.println("Enter Employee's Department Name");
				String EmpDept= scannerOB.next();
				System.out.println("Enter Employee's Grade");
				String Grade= scannerOB.next();
				System.out.println("Enter Employee's Designation");
				String Designation= scannerOB.next();
				System.out.println("Enter Employee's Gender");
				String Gender= scannerOB.next();
				System.out.println("Enter Employee's Basic Salary");
				int EmpBasic= scannerOB.nextInt();
			    System.out.println("Enter Employee's Marital Status");
				String MarStatus= scannerOB.next();
				System.out.println("Enter Employee's Address");
				String EmpAddress= scannerOB.next();
				System.out.println("Enter Employee's contact Number");
				String EmpContact= scannerOB.next();
				System.out.println("Enter Employee's Manager Code");
				int EmpMgr= scannerOB.nextInt();
				System.out.println("hello");
				
				
				try{ beanOB.setEmpID(EmpID);
				System.out.println(beanOB.getEmpID());
				
				beanOB.setEmpFirstName(EmpFirstname);
				
				beanOB.setEmpLastName(EmpLastname);
				
				beanOB.setEmpDOJ(EmpDOJ);
				
				beanOB.setEmpDOB(EmpDOB);
				
				beanOB.setEmpDeptID(EmpDeptID);
				
				beanOB.setDeptName(EmpDept);
				
				beanOB.setEmpGrade(Grade);
				
				beanOB.setEmpDesignation(Designation);
				
				beanOB.setEmpBasic(EmpBasic);
				
				beanOB.setEmpMaritalStatus(MarStatus);
				
				beanOB.setEmpAddress(EmpAddress);
				
				beanOB.setEmpContact(EmpContact);
				
				beanOB.setMgrID(EmpMgr);
				
				
				
				n=serviceOB.addEmployeeDetails(beanOB);
				System.out.println(n + "Rows updated"); 
				}
				catch(EmployeeException e)
				{ System.out.println(e);}
				
		        break;
			case 2:
				System.out.println("Enter Employee ID");
				int ModID = scannerOB.nextInt();
				System.out.println("Select the fields you want to modify");
				System.out.println("1. Employee's First Name 2.Employee's Last Name 3.Employee's Department 4.Employee's Grade 5.Employees's Designation 6.Employees's Basic Salary 7.Employees's Marital status 8.Employee's Address 9. Employee's Contact Number");
				int value2 = scannerOB.nextInt();
				switch (value2) {
				case 1: System.out.println("Enter Employee's new first name");
				String newFName = scannerOB.next();
				beanOB.setEmpFirstName(newFName);
				//empservice.updateFirstName(beanOB,newName);
					    break;
				case 2: System.out.println("Enter Employee's new last name");
				String newLName = scannerOB.next();
				beanOB.setEmpLastName(newLName);
			    break;
				case 3: System.out.println("Enter Employee's new Department");
				String newDept = scannerOB.next();
				beanOB.setDeptName(newDept);
				break;
				case 4: System.out.println("Enter Employee's new Grade");
				String newGrade = scannerOB.next();
				beanOB.setEmpGrade(newGrade);
				break;
				case 5: System.out.println("Enter Employee's new Designation");
				String newDesignation = scannerOB.next();
				beanOB.setEmpDesignation(newDesignation);
				break;
				case 6: System.out.println("Enter Employee's new Basic Salary");
				int newSalary = scannerOB.nextInt();
				beanOB.setEmpBasic(newSalary);
				break;
				case 7: System.out.println("Enter Employee's new Marital Status");
				String newMStatus = scannerOB.next();
				beanOB.setEmpMaritalStatus(newMStatus);
				break;
				case 8: System.out.println("Enter Employee's new Address");
				String newAddress = scannerOB.next();
				beanOB.setEmpAddress(newAddress);
				break;
				case 9: System.out.println("Enter Employee's new contact number");
				String newContact = scannerOB.next();
				beanOB.setEmpContact(newContact);
				break;
			    default:
					break;
				}
				break;
			
			case 3:System.out.println("Enter Employee ID");
			    int searchID = scannerOB.nextInt();
			    System.out.println("EmpID + EmpFirstName + EmpLastName + DeptName + EmpGrade + EmpDesignation");
			    n=serviceOB.displayEmployeeDetailsAdmin(beanOB);
			    {System.out.println(n +"rows affected");}
				
				break;

			default:
				break;
			}
			break;
		case "employee":
			System.out.println("WELCOME TO THE EMPLOYEE WORLD");
			System.out.println("1. Search for an employee 2. Apply for leave");
			int value3 = scannerOB.nextInt();
			switch (value3) {
			case 1:
				System.out.println("Select the field to check\n");
				System.out.println("1.EmployeeID");
				System.out.println("2.Employee's First Name");
				System.out.println("3.Employee's Last Name");
				System.out.println("4.Employee's Department");
				System.out.println("5.Employee's Grade");
				System.out.println("6.Employee's Marital Status");
				int value4 = scannerOB.nextInt();
				switch (value4) {
				case 1:System.out.println("Enter Employee ID");
				int searchID = scannerOB.nextInt();
                break;
				case 2:System.out.println("Enter Employee's First Name");
				String searchFName = scannerOB.next();
                break;
				case 3:System.out.println("Enter Employee's Last Name");
				String searchLName = scannerOB.next();
                break;
				case 4:System.out.println("Enter Employee's Department");
				String searchDept = scannerOB.next();
                break;
				case 5:System.out.println("Enter Employee's Grade");
				String searchGrade = scannerOB.next();
                break;
				case 6:System.out.println("Enter Employee's Marital Status");
				String searchMStatus = scannerOB.next();
                break;
                default:
					break;
				}
			case 2: 
				
				break;

			default:
				break;
			}
			
			break;

		default:
			break;
		}
		
		scannerOB.close();
		
		
	
		

}}
