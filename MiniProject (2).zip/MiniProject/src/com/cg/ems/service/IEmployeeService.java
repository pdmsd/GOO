package com.cg.ems.service;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.exception.EmployeeException;

public interface IEmployeeService {

	public abstract int addEmployeeDetails(EmployeeBean beanOB) throws EmployeeException;

	int displayEmployeeDetailsAdmin(EmployeeBean beanOB)
			throws EmployeeException;
	
}
