package com.cg.ems.service;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.dao.EmployeeDAO;
import com.cg.ems.dao.IEmployeeDAO;
import com.cg.ems.exception.EmployeeException;

public class EmployeeService implements IEmployeeService{
	
	IEmployeeDAO employeedao = new EmployeeDAO();

	@Override
	public int addEmployeeDetails(EmployeeBean beanOB) throws EmployeeException{
		
		return employeedao.addEmployeeDetails(beanOB);
		
	}
	@Override
	public int displayEmployeeDetailsAdmin(EmployeeBean beanOB) throws EmployeeException
	{
		return employeedao.displayEmployeeDetailsAdmin(beanOB);
	}

}
