package com.cg.ems.dao;





import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
//import java.util.ArrayList;




import java.time.LocalDate;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.EmployeeUtil;

public class EmployeeDAO implements IEmployeeDAO {
	static Logger log = Logger.getRootLogger();
	int storedStatus=0;
	
	private Connection conn = null;
    EmployeeBean beanOB = new EmployeeBean();
    EmployeeBean beanOB3 = new EmployeeBean();
    final LocalDate today = LocalDate.now();
    final Date sysdate = Date.valueOf(today);
    
    public EmployeeBean getaccess(String UserName, String Password ) throws EmployeeException {
    	EmployeeBean beanOB0 = new EmployeeBean();
    	conn = EmployeeUtil.getConnection();
    	try{Statement stmt = conn.createStatement();
    	
    	PreparedStatement preparedStatement = conn.prepareStatement("Select USERTYPE from User_Master where USERNAME=? and USERPASSWORD=?");
    	preparedStatement.setString(1, UserName);
    	preparedStatement.setString(2, Password);
    	
    	
    	ResultSet rs = preparedStatement.executeQuery();
    	while(rs.next()){
    		String type = rs.getString(1);
    		beanOB0.setUserType(type);
    		
    	}}
    	
    	catch(SQLException e)
		{      log.error("Error in getaccess() method");
			 throw new EmployeeException("NOT A VALID USER: "+e.getMessage());
		}
    	
    	return beanOB0;}
   
    public int searchModID(String ModID) throws EmployeeException{
    	conn= EmployeeUtil.getConnection();
    	
    	try {
			Statement stmt = conn.createStatement();
			PreparedStatement preparedStatement = conn.prepareStatement("Select EMP_ID from Employee where Emp_ID=?");
			preparedStatement.setString(1, ModID);
			ResultSet rs = preparedStatement.executeQuery();
			String employeeID="";
			while(rs.next()){
				storedStatus=1;
				employeeID = rs.getString(1);
			
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	
		return storedStatus;
		
    	
    }
    @Override
	public int updateEmployees(EmployeeBean beanOB,String value2) throws EmployeeException {
		conn = EmployeeUtil.getConnection();
		int s=0;
		try{if(value2=="1")
			{Statement stmt = conn.createStatement();
			PreparedStatement preparedStatement = conn.prepareStatement("Update Employee set EMP_FIRST_NAME=? where EMP_ID= ?");
		preparedStatement.setString(1, beanOB.getEmpFirstName());
		preparedStatement.setString(2, beanOB.getEmpID());
		s = preparedStatement.executeUpdate();
		
		}
		else if(value2=="2")
		{Statement stmt = conn.createStatement();
		PreparedStatement preparedStatement = conn.prepareStatement("Update Employee set EMP_LAST_NAME=? where EMP_ID= ?");
	preparedStatement.setString(1, beanOB.getEmpLastName());
	preparedStatement.setString(2, beanOB.getEmpID());
	s = preparedStatement.executeUpdate();
	
	}
		else if(value2=="3")
		{Statement stmt = conn.createStatement();
		PreparedStatement preparedStatement = conn.prepareStatement("Update Employee set EMP_GRADE=? where EMP_ID= ?");
	preparedStatement.setString(1, beanOB.getEmpGrade());
	preparedStatement.setString(2, beanOB.getEmpID());
	s = preparedStatement.executeUpdate();
	
	}
		else if(value2=="4")
		{Statement stmt = conn.createStatement();
		PreparedStatement preparedStatement = conn.prepareStatement("Update Employee set EMP_DESIGNATION=? where EMP_ID= ?");
	preparedStatement.setString(1, beanOB.getEmpDesignation());
	preparedStatement.setString(2, beanOB.getEmpID());
	s = preparedStatement.executeUpdate();
	
	}
		else if(value2=="5")
		{Statement stmt = conn.createStatement();
		PreparedStatement preparedStatement = conn.prepareStatement("Update Employee set EMP_BASIC=? where EMP_ID= ?");
	preparedStatement.setInt(1, beanOB.getEmpBasic());
	preparedStatement.setString(2, beanOB.getEmpID());
	s = preparedStatement.executeUpdate();
	
	}
		else if(value2=="6")
		{Statement stmt = conn.createStatement();
		PreparedStatement preparedStatement = conn.prepareStatement("Update Employee set EMP_GENDER=? where EMP_ID= ?");
	preparedStatement.setString(1, beanOB.getEmpGender());
	preparedStatement.setString(2, beanOB.getEmpID());
	s = preparedStatement.executeUpdate();
	
	}
		else if(value2=="7")
		{Statement stmt = conn.createStatement();
		PreparedStatement preparedStatement = conn.prepareStatement("Update Employee set EMP_MARITAL_STATUS=? where EMP_ID= ?");
	preparedStatement.setString(1, beanOB.getEmpMaritalStatus());
	preparedStatement.setString(2, beanOB.getEmpID());
	s = preparedStatement.executeUpdate();
	
	}
		else if(value2=="8")
		{Statement stmt = conn.createStatement();
		PreparedStatement preparedStatement = conn.prepareStatement("Update Employee set EMP_HOME_ADDRESS=? where EMP_ID= ?");
	preparedStatement.setString(1, beanOB.getEmpAddress());
	preparedStatement.setString(2, beanOB.getEmpID());
	s = preparedStatement.executeUpdate();
	
	}
		else if(value2=="9")
		{Statement stmt = conn.createStatement();
		PreparedStatement preparedStatement = conn.prepareStatement("Update Employee set EMP_CONTACT_NUM=? where EMP_ID= ?");
	preparedStatement.setString(1, beanOB.getEmpContact());
	preparedStatement.setString(2, beanOB.getEmpID());
	s = preparedStatement.executeUpdate();
	
	}}
		catch(Exception e)
		{      log.error("Error in updateemployees() method");
			 throw new EmployeeException("UPDATE NOT POSSIBLE: "+e.getMessage());
		}
	 return s;
	}
    
	@Override
	public int addEmployeeDetails(EmployeeBean beanOB) throws EmployeeException {
		conn = EmployeeUtil.getConnection();
		String empID="";
		try{
		Statement stmt = conn.createStatement(); 
		
	PreparedStatement preparedStatements=conn.prepareStatement("Select Dept_ID from Department where Dept_Name=?");	
	preparedStatements.setString(1, beanOB.getDeptName());
	ResultSet rs=preparedStatements.executeQuery(); 
	int Dept_ID=0;
	while(rs.next()){  
		Dept_ID = rs.getInt(1);
        
		}
	PreparedStatement preparedStatement=conn.prepareStatement("INSERT INTO Employee values(empID.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?)");
	PreparedStatement preparedStatement2=conn.prepareStatement("INSERT INTO User_Master values(?,pwrd.nextval,'employee',empID.currval)");
	
	preparedStatement.setString(1, beanOB.getEmpFirstName());
	preparedStatement.setString(2, beanOB.getEmpLastName());
	preparedStatement.setDate(3, beanOB.getEmpDOB());
	preparedStatement.setDate(4, beanOB.getEmpDOJ());
	preparedStatement.setInt(5, Dept_ID);
	preparedStatement.setString(6, beanOB.getEmpGrade());
	
	preparedStatement.setString(7, beanOB.getEmpDesignation());
	preparedStatement.setInt(8, beanOB.getEmpBasic());
	preparedStatement.setString(9, beanOB.getEmpGender());
	preparedStatement.setString(10, beanOB.getEmpMaritalStatus());
	preparedStatement.setString(11, beanOB.getEmpAddress());
	preparedStatement.setString(12, beanOB.getEmpContact());
	preparedStatement.setInt(13, beanOB.getMgrID());
	
	preparedStatement2.setString(1, beanOB.getUserName());
	
	storedStatus=preparedStatement.executeUpdate();
	storedStatus=preparedStatement2.executeUpdate();
	PreparedStatement preparedStatement4=conn.prepareStatement("Select empID.currval from dual");
	ResultSet rs1=preparedStatement4.executeQuery();
	while(rs1.next())
		empID=rs1.getString(1);
	System.out.println(empID);
	PreparedStatement preparedStatement3=conn.prepareStatement("Insert into Leave_History(EMP_ID,LEAVE_BALANCE,APPLIED_DATE) values(?,12,SYSDATE)");
	preparedStatement3.setString(1, empID);
	storedStatus=preparedStatement3.executeUpdate();
	
	
	}
		catch(Exception e)
		{     log.error("Error in addemployeedetails() method");
			 throw new EmployeeException("ADD EMPLOYEES NOT POSSIBLE: "+e.getMessage());
		}
	
		
		
		return storedStatus;
	}
	
	
	
	public ArrayList<EmployeeBean> displayAll() throws EmployeeException
	{ ArrayList<EmployeeBean> allrecords = new ArrayList<EmployeeBean>();
	conn = EmployeeUtil.getConnection();
	try{
		Statement stmt = conn.createStatement();
		PreparedStatement preparedStatement = conn.prepareStatement("Select * from Employee");
		ResultSet rs = preparedStatement.executeQuery();
		while(rs.next()) {
			 String eid = rs.getString(1);
			 String efname=rs.getString(2);
			 String elname=rs.getString(3);
			 Date edob=rs.getDate(4);
			 Date edoj=rs.getDate(5);
			 int deptid=rs.getInt(6);
			 String egrade=rs.getString(7);
			 String edesign=rs.getString(8);
			 int ebasic=rs.getInt(9);
			 String egender=rs.getString(10);
			 String emstatus=rs.getString(11);
			 String eadd=rs.getString(12);
			 String econtact=rs.getString(13);
			 int mgrid=rs.getInt(14);
			
			 EmployeeBean e = new EmployeeBean();
			 
			 e.setEmpID(eid);
			 e.setEmpFirstName(efname);
			 e.setEmpLastName(elname);
			 e.setEmpDOB(edob);
			 e.setEmpDOJ(edoj);
			 e.setDeptID(deptid);
			 e.setEmpGrade(egrade);
			 e.setEmpDesignation(edesign);
			 e.setEmpBasic(ebasic);
			 e.setEmpGender(egender);
			 e.setEmpMaritalStatus(emstatus);
			 e.setEmpAddress(eadd);
			 e.setEmpContact(econtact);
			 e.setMgrID(mgrid);
			
			 
			 allrecords.add(e);
			 
		}

	}  catch(Exception e)
	{    log.error("Error in displayall() method");
		 throw new EmployeeException("DISPLAY ALL NOT POSSIBLE: "+e.getMessage());
	}
	
		return allrecords;}
	
	@Override
	public EmployeeBean displayEmployeeDetailsUser(String searchID)
			throws EmployeeException {
	
		return null;
	}
	
	public ArrayList<EmployeeBean> searchEmployees(String searchID, String searchFName, String searchLName, String searchDept, String searchGrade, String searchMStatus) throws EmployeeException
	{
		ArrayList<EmployeeBean> searchemp = new ArrayList<EmployeeBean>();
		try {conn=EmployeeUtil.getConnection();
		
		PreparedStatement preparedStatement=conn.prepareStatement("Select EMP_ID, EMP_FIRST_NAME, EMP_LAST_NAME, EMP_GRADE, EMP_DESIGNATION from Employee where EMP_ID=? or EMP_FIRST_NAME=? or EMP_LAST_NAME=? or EMP_GRADE=? or EMP_MARITAL_STATUS=?");
		preparedStatement.setString(1, searchID);
		preparedStatement.setString(2, searchFName);
		preparedStatement.setString(3, searchLName);
		preparedStatement.setString(4, searchGrade);
		preparedStatement.setString(5, searchMStatus);
		
		ResultSet rs = preparedStatement.executeQuery();
		 while(rs.next()) {
			 EmployeeBean beanOBJ6 = new EmployeeBean();
			 String eid = rs.getString(1);
			 String efname=rs.getString(2);
			 String elname=rs.getString(3);
			 String egrade=rs.getString(4);
			 String edesign=rs.getString(5);
			 
			 beanOBJ6.setEmpID(eid);
			 beanOBJ6.setEmpFirstName(efname);
			 beanOBJ6.setEmpLastName(elname);
			 beanOBJ6.setEmpGrade(egrade);
			 beanOBJ6.setEmpDesignation(edesign);
			 searchemp.add(beanOBJ6);
			 
			  }}
		 catch(Exception e)
			{      log.error("Error in displayrecords() method");
				 throw new EmployeeException("RECORDS CAN NOT BE DISPLAYED: "+e.getMessage());
			}
		return searchemp;
		
		}

	@Override
	public EmployeeBean displayEmployeeDetailsAdmin(String searchID)
			throws EmployeeException {
		return null;
	}

	
      public int EmpORMgr(String UserName) throws EmployeeException{
    	  int status = 0;
    	  try{conn=EmployeeUtil.getConnection();
    	 
    	  PreparedStatement preparedStatement = conn.prepareStatement("select * from User_Master,Employee where User_Master.UserID = Employee.MGR_ID and USERNAME=?");
    	  preparedStatement.setString(1, UserName);
    	  ResultSet rs = preparedStatement.executeQuery();
  		if(rs.next()){
  			status=1;
  		} else status=0;
  		
    	  }
    	  catch(Exception e)
			{      log.error("Error in EmpORMgr() method");
				 throw new EmployeeException("RECORDS CAN NOT BE DISPLAYED: "+e.getMessage());
			}
    	  
    	  return status;
      }

	@Override
	public int applyLeave(String UserName, Date leaveFrom1,int NoOfDays) throws EmployeeException {
		
		try{ 
		storedStatus=0;
		
			conn=EmployeeUtil.getConnection();
			PreparedStatement preparedStatement1=conn.prepareStatement("Select USERID,LEAVE_BALANCE from User_Master,Leave_History where User_Master.USERNAME=? and User_Master.USERID=Leave_History.EMP_ID");	
			preparedStatement1.setString(1, UserName);
			ResultSet rs=preparedStatement1.executeQuery(); 
			String USER_ID="";
			int Leave_Balance=0;
		
			while(rs.next()){  
				USER_ID = rs.getString(1);
				Leave_Balance = rs.getInt(2);}
			
			if(Leave_Balance>NoOfDays)
			{PreparedStatement preparedStatement = conn.prepareStatement("insert into Leave_History(LEAVE_ID,EMP_ID,LEAVE_BALANCE,NO_OF_DAYS_APPLIED,DATE_FROM,Status) values(leaveID.nextval,?,?,?,?,'applied',SYSDATE)");
			
			preparedStatement.setString(1, USER_ID);
			preparedStatement.setInt(2, Leave_Balance);
			preparedStatement.setInt(3, NoOfDays);
			preparedStatement.setDate(4, leaveFrom1);
			storedStatus=preparedStatement.executeUpdate();
			PreparedStatement preparedStatement2 = conn.prepareStatement("update Leave_History set DATE_TO = ? + ? where EMP_ID=?");
			preparedStatement2.setDate(1,leaveFrom1);
			preparedStatement2.setInt(2, NoOfDays);
			preparedStatement2.setString(3, USER_ID);
			//preparedStatement2.
			storedStatus=preparedStatement2.executeUpdate();
			storedStatus=1;}
			
			}
		catch(Exception e)
		{      log.error("Error in applyLeave() method");
			 throw new EmployeeException("Leave NOT DONE: "+e.getMessage());
		}
		
		return storedStatus;
	}

	@Override
	public ArrayList<EmployeeBean> leaveleft(String UserName) throws EmployeeException{
		conn = EmployeeUtil.getConnection();
		ArrayList<EmployeeBean> leavedetail = new ArrayList<EmployeeBean>();
		EmployeeBean beanOB6 = new EmployeeBean();
		try { Statement stmt = conn.createStatement();
			
			PreparedStatement preparedStatement = conn.prepareStatement("Select USERID from User_Master where USERNAME=?");
			preparedStatement.setString(1, UserName);
			ResultSet rs=preparedStatement.executeQuery();
			String UID="";
			while(rs.next())
			{ UID = rs.getString(1);
			System.out.println(UID);
			
			PreparedStatement preparedStatement2 = conn.prepareStatement("Select * from Leave_History where EMP_ID=?");
			preparedStatement2.setString(1,UID);
			String stat="Approved";
			
				ResultSet rs2= preparedStatement2.executeQuery();
				while(rs2.next())
				{
					EmployeeBean array1 = new EmployeeBean();
					array1.setLeaveID(rs2.getInt(1));
					array1.setEmpID(rs2.getString(2));
					array1.setLeaveBalance(rs2.getInt(3));
					array1.setNoOFDays(rs2.getInt(4));
					array1.setDateFrom(rs2.getDate(5));
					array1.setDateTo(rs2.getDate(6));
					
					array1.setApplied_Date(rs2.getDate(8));
					
					if(rs.getDate(8) !=null && rs.getString(7).equals("applied"))
					{int compare=sysdate.compareTo(rs.getDate(8));
					if(compare>3)
						{  PreparedStatement preparedStatement4 = conn.prepareStatement("update table Leave_history set Status=? where Emp_ID=?");
						preparedStatement4.setString(1, stat);
						preparedStatement4.setString(2,UID);
						storedStatus=preparedStatement4.executeUpdate();
						}
					
					}
					array1.setStatus(rs2.getString(7));
					leavedetail.add(array1);
				}
				
			}
		
		} catch (SQLException e) {
			System.out.println("Problem in leaveApply method" + e.getMessage());		}
		
		return leavedetail;
	}

	@Override
	public ArrayList<EmployeeBean> wantsLeave(String UserName) throws EmployeeException {
		ArrayList<EmployeeBean> seekLeave = new ArrayList<EmployeeBean>();
		conn = EmployeeUtil.getConnection();
		try { Statement stmt = conn.createStatement();
		
		PreparedStatement preparedStatement = conn.prepareStatement("Select USERID from User_Master where USERNAME=?");
		preparedStatement.setString(1, UserName);
		ResultSet rs=preparedStatement.executeQuery();
		String UID="";
		while(rs.next())
		{ UID = rs.getString(1);
		
		PreparedStatement preparedStatement1 = conn.prepareStatement("Select EMP_ID from Employee where MGR_ID=?");
		preparedStatement1.setString(1, UID);
		
		ResultSet rs1=preparedStatement1.executeQuery();
		
		String stat="applied";
		while(rs1.next())
		{
		PreparedStatement preparedStatement2 = conn.prepareStatement("Select * from Leave_History where EMP_ID=? and Status=?");
		preparedStatement2.setString(1, rs1.getString(1));
		preparedStatement2.setString(2, stat );
			
			ResultSet rs2= preparedStatement2.executeQuery();
			while(rs2.next())
			{
				EmployeeBean array1 = new EmployeeBean();
				array1.setLeaveID(rs2.getInt(1));
				array1.setEmpID(rs2.getString(2));
				array1.setLeaveBalance(rs2.getInt(3));
				array1.setNoOFDays(rs2.getInt(4));
				array1.setDateFrom(rs2.getDate(5));
				array1.setDateTo(rs2.getDate(6));
				array1.setStatus(rs2.getString(7));
				seekLeave.add(array1);
			}
			
		}
		
		}
		
	} catch (SQLException e) {
		System.out.println("Problem in want leaveApply method" + e.getMessage());		}
	
	return seekLeave;
	}

	@Override
	public int approveLeave(String ELID, int ELID2) throws EmployeeException {
		conn=EmployeeUtil.getConnection();
		int storedStatus=0;
		int LeaveMinus=0;
		String stat="Approved";
		try {
			PreparedStatement preparedStatement = conn.prepareStatement("Select NO_OF_DAYS_APPLIED from Leave_History where Leave_ID = ? and EMP_ID = ?");
			preparedStatement.setInt(1, ELID2);
			preparedStatement.setString(2, ELID);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next())
			{
				LeaveMinus = rs.getInt(1);
			}
			PreparedStatement preparedStatement1 = conn.prepareStatement("update Leave_History set Status=?, Leave_Balance=Leave_Balance+? where EMP_ID=? and Leave_ID=?");
			preparedStatement1.setString(1, stat);
			preparedStatement1.setInt(2, -LeaveMinus);
			preparedStatement1.setString(3, ELID);
			preparedStatement1.setInt(4, ELID2);
			
			storedStatus=preparedStatement1.executeUpdate();
		} catch (SQLException e) {
			
			System.out.println("Problem in approveLeave method" + e.getMessage());	
		}
		return storedStatus;
	}

	@Override
	public int rejectLeave(String ELID, int ELID2) throws EmployeeException {
		conn=EmployeeUtil.getConnection();
		String stat="Rejected";
		try {
			PreparedStatement preparedStatement = conn.prepareStatement("update Leave_history set Status=? where  EMP_ID=? and Leave_ID=?");
			preparedStatement.setString(1, stat);
			preparedStatement.setString(2, ELID);
			preparedStatement.setInt(3, ELID2);
			storedStatus = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Problem in rejectLeave method" + e.getMessage());
		}
		return storedStatus;
	}

	@Override
	public int checkleave(String ELID, int ELID2) throws EmployeeException {
		conn=EmployeeUtil.getConnection();
		String stat="applied";
		int checkleavevalue=0;
		try {
			Statement stmt = conn.createStatement();
			PreparedStatement preparedStatement = conn.prepareStatement("Select * from Leave_History where EMP_ID = ? and Leave_ID=? and Status=?");
			preparedStatement.setString(1, ELID);
			preparedStatement.setInt(2, ELID2);
			preparedStatement.setString(3, stat);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next())
				{checkleavevalue=1;}
		} catch (SQLException e) {
            System.out.println("Problem in checkleave method" + e.getMessage());
		}
		return checkleavevalue;
	}

}
