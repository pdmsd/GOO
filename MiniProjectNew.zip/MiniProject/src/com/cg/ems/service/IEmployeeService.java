package com.cg.ems.service;

import java.sql.Date;
import java.util.ArrayList;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.exception.EmployeeException;

public interface IEmployeeService {

	public abstract int addEmployeeDetails(EmployeeBean beanOB) throws EmployeeException;

	EmployeeBean displayEmployeeDetailsUser(String searchID) throws EmployeeException;

	EmployeeBean displayEmployeeDetailsAdmin(String searchID) throws EmployeeException;
	
	public abstract ArrayList<EmployeeBean> searchEmployees(String searchID, String searchFName, String searchLName, String searchDept, String searchGrade, String searchMStatus) throws EmployeeException;
	
	public abstract int updateEmployees(EmployeeBean beanOB,String value2) throws EmployeeException;
	
	int EmpORMgr(String UserName) throws EmployeeException;
	
	public abstract int applyLeave(String UserName, Date leaveFrom1, int NoOFDays) throws EmployeeException;
	
	public abstract int searchModID(String ModID) throws EmployeeException;
	
	public abstract ArrayList<EmployeeBean> leaveleft(String UserName) throws EmployeeException;
	
	public abstract ArrayList<EmployeeBean> wantsLeave(String UserName) throws EmployeeException;
	
	public abstract int approveLeave(String ELID, int ELID2) throws EmployeeException;
	
	public abstract int rejectLeave(String ELID, int ELID2) throws EmployeeException;
	
	public abstract int checkleave(String ELID, int ELID2) throws EmployeeException;
}
