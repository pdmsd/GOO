package com.cg.ems.dao;

public class IQueryMapper {
	
	public static final String INSERT_QUERY1="INSERT INTO Employee values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	public static final String SELECT_DEPTID="Select Dept_ID from Department where Dept_Name=?";
    public static final String Employee_SEARCH="Select EMP_ID, EMP_FIRST_NAME, EMP_LAST_NAME,EMP_GRADE, EMP_DESIGNATION from Employee where EMP_ID=?";
    public static final String Access_Query="Select USERTYPE from User_Master where USERNAME=? and USERPASSWORD=?";
    public static final String Update_1="Update Employee set EMP_FIRST_NAME=? where EMP_ID= ?";
    public static final String Update_2="Update Employee set EMP_LAST_NAME=? where EMP_ID= ?";
    public static final String Update_3="Update Employee set EMP_GRADE=? where EMP_ID= ?";
    public static final String Update_4="Update Employee set EMP_DESIGNATION=? where EMP_ID= ?";
    public static final String Update_5="Update Employee set EMP_BASIC=? where EMP_ID= ?";
    public static final String Update_6="Update Employee set EMP_GENDER=? where EMP_ID= ?";
    public static final String Update_7="Update Employee set EMP_MARITAL_STATUS=? where EMP_ID= ?";
    public static final String Update_8="Update Employee set EMP_HOME_ADDRESS=? where EMP_ID= ?";
    public static final String Update_9="Update Employee set EMP_CONTACT_NUM=? where EMP_ID= ?";
    public static final String search_employee="Select EMP_ID, EMP_FIRST_NAME, EMP_LAST_NAME, EMP_GRADE, EMP_DESIGNATION from Employee where EMP_ID=? or EMP_FIRST_NAME=? or EMP_LAST_NAME=? or EMP_GRADE=? or EMP_MARITAL_STATUS=?";
}