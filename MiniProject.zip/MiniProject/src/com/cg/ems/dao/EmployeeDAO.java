package com.cg.ems.dao;

import java.sql.Connection;

import com.cg.ems.bean.EmployeeBean;

public class EmployeeDAO implements IEmployeeDAO {
	
	//dbutil
	private Connection conn = null;

	@Override
	public int addEmployeeDetails(EmployeeBean ob) {
		
		//string query
		//prep stmt
		//stmt.setString(1,ob.getName())
		//return executeUpdate()
		
		
		return 0;
	}

}
