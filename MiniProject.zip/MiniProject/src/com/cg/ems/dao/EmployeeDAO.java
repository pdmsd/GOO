package com.cg.ems.dao;





import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
//import java.util.ArrayList;




import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.EmployeeUtil;

public class EmployeeDAO implements IEmployeeDAO {
	static Logger log = Logger.getRootLogger();
	int storedStatus=0;
	
	//dbutil
	private Connection conn = null;
    EmployeeBean beanOB = new EmployeeBean();
    EmployeeBean beanOB3 = new EmployeeBean();
    
    public EmployeeBean getaccess(String UserName, String Password ) throws EmployeeException {
    	EmployeeBean beanOB0 = new EmployeeBean();
    	conn = EmployeeUtil.getConnection();
    	try{Statement stmt = conn.createStatement();
    	//System.out.println(UserName);
    	//System.out.println(Password);
    	PreparedStatement preparedStatement = conn.prepareStatement("Select USERTYPE from User_Master where USERNAME=? and USERPASSWORD=?");
    	preparedStatement.setString(1, UserName);
    	preparedStatement.setString(2, Password);
    	
    	
    	ResultSet rs = preparedStatement.executeQuery();
    	while(rs.next()){
    		String type = rs.getString(1);
    		beanOB0.setUserType(type);
    		//System.out.println(type);
    	}}
    	
    	catch(SQLException e)
		{      log.error("Error in getaccess() method");
			 throw new EmployeeException("NOT A VALID USER: "+e.getMessage());
		}
    	
    	return beanOB0;}
   
    @Override
	public int updateEmployees(EmployeeBean beanOB,int value2) throws EmployeeException {
		conn = EmployeeUtil.getConnection();
		int s=0;
		try{if(value2==1)
			{Statement stmt = conn.createStatement();
			PreparedStatement preparedStatement = conn.prepareStatement("Update Employee set EMP_FIRST_NAME=? where EMP_ID= ?");
		preparedStatement.setString(1, beanOB.getEmpFirstName());
		preparedStatement.setString(2, beanOB.getEmpID());
		s = preparedStatement.executeUpdate();
		
		}
		else if(value2==2)
		{Statement stmt = conn.createStatement();
		PreparedStatement preparedStatement = conn.prepareStatement("Update Employee set EMP_LAST_NAME=? where EMP_ID= ?");
	preparedStatement.setString(1, beanOB.getEmpLastName());
	preparedStatement.setString(2, beanOB.getEmpID());
	s = preparedStatement.executeUpdate();
	
	}
		else if(value2==3)
		{Statement stmt = conn.createStatement();
		PreparedStatement preparedStatement = conn.prepareStatement("Update Employee set EMP_GRADE=? where EMP_ID= ?");
	preparedStatement.setString(1, beanOB.getEmpGrade());
	preparedStatement.setString(2, beanOB.getEmpID());
	s = preparedStatement.executeUpdate();
	
	}
		else if(value2==4)
		{Statement stmt = conn.createStatement();
		PreparedStatement preparedStatement = conn.prepareStatement("Update Employee set EMP_DESIGNATION=? where EMP_ID= ?");
	preparedStatement.setString(1, beanOB.getEmpDesignation());
	preparedStatement.setString(2, beanOB.getEmpID());
	s = preparedStatement.executeUpdate();
	
	}
		else if(value2==5)
		{Statement stmt = conn.createStatement();
		PreparedStatement preparedStatement = conn.prepareStatement("Update Employee set EMP_BASIC=? where EMP_ID= ?");
	preparedStatement.setInt(1, beanOB.getEmpBasic());
	preparedStatement.setString(2, beanOB.getEmpID());
	s = preparedStatement.executeUpdate();
	
	}
		else if(value2==6)
		{Statement stmt = conn.createStatement();
		PreparedStatement preparedStatement = conn.prepareStatement("Update Employee set EMP_GENDER=? where EMP_ID= ?");
	preparedStatement.setString(1, beanOB.getEmpGender());
	preparedStatement.setString(2, beanOB.getEmpID());
	s = preparedStatement.executeUpdate();
	
	}
		else if(value2==7)
		{Statement stmt = conn.createStatement();
		PreparedStatement preparedStatement = conn.prepareStatement("Update Employee set EMP_MARITAL_STATUS=? where EMP_ID= ?");
	preparedStatement.setString(1, beanOB.getEmpMaritalStatus());
	preparedStatement.setString(2, beanOB.getEmpID());
	s = preparedStatement.executeUpdate();
	
	}
		else if(value2==8)
		{Statement stmt = conn.createStatement();
		PreparedStatement preparedStatement = conn.prepareStatement("Update Employee set EMP_HOME_ADDRESS=? where EMP_ID= ?");
	preparedStatement.setString(1, beanOB.getEmpAddress());
	preparedStatement.setString(2, beanOB.getEmpID());
	s = preparedStatement.executeUpdate();
	
	}
		else if(value2==9)
		{Statement stmt = conn.createStatement();
		PreparedStatement preparedStatement = conn.prepareStatement("Update Employee set EMP_CONTACT_NUM=? where EMP_ID= ?");
	preparedStatement.setString(1, beanOB.getEmpContact());
	preparedStatement.setString(2, beanOB.getEmpID());
	s = preparedStatement.executeUpdate();
	
	}}
		catch(Exception e)
		{      log.error("Error in updateemployees() method");
			 throw new EmployeeException("UPDATE NOT POSSIBLE: "+e.getMessage());
		}
	 return s;
	}
    
	@Override
	public int addEmployeeDetails(EmployeeBean beanOB) throws EmployeeException {
		conn = EmployeeUtil.getConnection();
		String empID="";
		try{
		Statement stmt = conn.createStatement(); 
		
	PreparedStatement preparedStatements=conn.prepareStatement("Select Dept_ID from Department where Dept_Name=?");	
	preparedStatements.setString(1, beanOB.getDeptName());
	ResultSet rs=preparedStatements.executeQuery(); 
	int Dept_ID=0;
	while(rs.next()){  
		Dept_ID = rs.getInt(1);
         //beanOB.setDeptID(rs.getInt(1)); 
		}
	PreparedStatement preparedStatement=conn.prepareStatement("INSERT INTO Employee values(empID.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?)");
	PreparedStatement preparedStatement2=conn.prepareStatement("INSERT INTO User_Master values(?,pwrd.nextval,'employee',empID.currval)");
	
	//preparedStatement.setString(1, beanOB.getEmpID());
	
	preparedStatement.setString(1, beanOB.getEmpFirstName());
	preparedStatement.setString(2, beanOB.getEmpLastName());
	preparedStatement.setDate(3, beanOB.getEmpDOB());
	preparedStatement.setDate(4, beanOB.getEmpDOJ());
	preparedStatement.setInt(5, Dept_ID);
	preparedStatement.setString(6, beanOB.getEmpGrade());
	//preparedStatement.setString(6, beanOB.getDeptName());
	preparedStatement.setString(7, beanOB.getEmpDesignation());
	preparedStatement.setInt(8, beanOB.getEmpBasic());
	preparedStatement.setString(9, beanOB.getEmpGender());
	preparedStatement.setString(10, beanOB.getEmpMaritalStatus());
	preparedStatement.setString(11, beanOB.getEmpAddress());
	preparedStatement.setString(12, beanOB.getEmpContact());
	preparedStatement.setInt(13, beanOB.getMgrID());
	
	preparedStatement2.setString(1, beanOB.getUserName());
	//preparedStatements.setInt(1, beanOB.getDeptID());
	
	storedStatus=preparedStatement.executeUpdate();
	storedStatus=preparedStatement2.executeUpdate();
	PreparedStatement preparedStatement4=conn.prepareStatement("Select empID.currval from dual");
	ResultSet rs1=preparedStatement4.executeQuery();
	while(rs1.next())
		empID=rs1.getString(1);
	System.out.println(empID);
	PreparedStatement preparedStatement3=conn.prepareStatement("Insert into Leave_History(EMP_ID,LEAVE_BALANCE) values(?,12)");
	preparedStatement3.setString(1, empID);
	storedStatus=preparedStatement3.executeUpdate();
	
	
	}
		catch(Exception e)
		{     log.error("Error in addemployeedetails() method");
			 throw new EmployeeException("ADD EMPLOYEES NOT POSSIBLE: "+e.getMessage());
		}
	
		
		
		return storedStatus;
	}
	
	
	
	public ArrayList<EmployeeBean> displayAll() throws EmployeeException
	{ ArrayList<EmployeeBean> allrecords = new ArrayList<EmployeeBean>();
	conn = EmployeeUtil.getConnection();
	try{
		Statement stmt = conn.createStatement();
		PreparedStatement preparedStatement = conn.prepareStatement("Select * from Employee");
		//PreparedStatement preparedStatements = conn.prepareStatement("Select * from Department");
		ResultSet rs = preparedStatement.executeQuery();
		while(rs.next()) {
			 String eid = rs.getString(1);
			 String efname=rs.getString(2);
			 String elname=rs.getString(3);
			 Date edob=rs.getDate(4);
			 Date edoj=rs.getDate(5);
			 int deptid=rs.getInt(6);
			 String egrade=rs.getString(7);
			 String edesign=rs.getString(8);
			 int ebasic=rs.getInt(9);
			 String egender=rs.getString(10);
			 String emstatus=rs.getString(11);
			 String eadd=rs.getString(12);
			 String econtact=rs.getString(13);
			 int mgrid=rs.getInt(14);
			
			 
			 //no. of records=no. of bean objects created
			 
			 EmployeeBean e = new EmployeeBean();
			 
			 e.setEmpID(eid);
			 e.setEmpFirstName(efname);
			 e.setEmpLastName(elname);
			 e.setEmpDOB(edob);
			 e.setEmpDOJ(edoj);
			 e.setDeptID(deptid);
			 e.setEmpGrade(egrade);
			 e.setEmpDesignation(edesign);
			 e.setEmpBasic(ebasic);
			 e.setEmpGender(egender);
			 e.setEmpMaritalStatus(emstatus);
			 e.setEmpAddress(eadd);
			 e.setEmpContact(econtact);
			 e.setMgrID(mgrid);
			 //System.out.println(e.getDeptID());
			 
			 allrecords.add(e);
			 
		}

	}  catch(Exception e)
	{    log.error("Error in displayall() method");
		 throw new EmployeeException("DISPLAY ALL NOT POSSIBLE: "+e.getMessage());
	}
	
		return allrecords;}
	
	@Override
	public EmployeeBean displayEmployeeDetailsUser(String searchID)
			throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}
	
	public ArrayList<EmployeeBean> searchEmployees(String searchID, String searchFName, String searchLName, String searchDept, String searchGrade, String searchMStatus) throws EmployeeException
	{
		ArrayList<EmployeeBean> searchemp = new ArrayList<EmployeeBean>();
		try {conn=EmployeeUtil.getConnection();
		//System.out.println(searchID + searchFName + searchLName + searchGrade + searchMStatus);
		PreparedStatement preparedStatement=conn.prepareStatement("Select EMP_ID, EMP_FIRST_NAME, EMP_LAST_NAME, EMP_GRADE, EMP_DESIGNATION from Employee where EMP_ID=? or EMP_FIRST_NAME=? or EMP_LAST_NAME=? or EMP_GRADE=? or EMP_MARITAL_STATUS=?");
		//PreparedStatement preparedStatement=conn.prepareStatement("Select EMP_FIRST_NAME from Employee where EMPID=?");
		preparedStatement.setString(1, searchID);
		preparedStatement.setString(2, searchFName);
		preparedStatement.setString(3, searchLName);
		preparedStatement.setString(4, searchGrade);
		preparedStatement.setString(5, searchMStatus);
		//System.out.println("new " + searchID + searchFName + searchLName + searchGrade + searchMStatus);
		ResultSet rs = preparedStatement.executeQuery();
		 while(rs.next()) {
			 EmployeeBean beanOBJ6 = new EmployeeBean();
			 String eid = rs.getString(1);
			 String efname=rs.getString(2);
			 //System.out.println(efname);
			 //System.out.println(efname);
			 String elname=rs.getString(3);
			 //System.out.println(elname);
			 String egrade=rs.getString(4);
			 String edesign=rs.getString(5);
			 
			 beanOBJ6.setEmpID(eid);
			 beanOBJ6.setEmpFirstName(efname);
			 beanOBJ6.setEmpLastName(elname);
			 beanOBJ6.setEmpGrade(egrade);
			 beanOBJ6.setEmpDesignation(edesign);
			 searchemp.add(beanOBJ6);
			 
			  }}
		 catch(Exception e)
			{      log.error("Error in displayrecords() method");
				 throw new EmployeeException("RECORDS CAN NOT BE DISPLAYED: "+e.getMessage());
			}
		return searchemp;
		
		}



	@Override
	public EmployeeBean displayEmployeeDetailsAdmin(String searchID)
			throws EmployeeException {
		return null;
	}

	
      public int EmpORMgr(String UserName) throws EmployeeException{
    	  int status = 0;
    	  try{conn=EmployeeUtil.getConnection();
    	 
    	  PreparedStatement preparedStatement = conn.prepareStatement("select * from User_Master,Employee where User_Master.UserID = Employee.MGR_ID and USERNAME=?");
    	  preparedStatement.setString(1, UserName);
    	  ResultSet rs = preparedStatement.executeQuery();
  		if(rs.next()){
  			status=1;
  		} else status=0;
  		
    	  }
    	  catch(Exception e)
			{      log.error("Error in EmpORMgr() method");
				 throw new EmployeeException("RECORDS CAN NOT BE DISPLAYED: "+e.getMessage());
			}
    	  
    	  return status;
      }

	@Override
	public int applyLeave(String UserName, Date leaveFrom1,int NoOfDays) throws EmployeeException {
		//System.out.println(UserName);
		try{ 
		storedStatus=0;
		//System.out.println(UserName);
			conn=EmployeeUtil.getConnection();
			PreparedStatement preparedStatement1=conn.prepareStatement("Select USERID,LEAVE_BALANCE from User_Master,Leave_History where User_Master.USERNAME=? and User_Master.USERID=Leave_History.EMP_ID");	
			preparedStatement1.setString(1, UserName);
			ResultSet rs=preparedStatement1.executeQuery(); 
			String USER_ID="";
			int Leave_Balance=0;
			//Date leaveTo = leaveFrom1 + NoOfDays;
			while(rs.next()){  
				USER_ID = rs.getString(1);
				Leave_Balance = rs.getInt(2);}
			//System.out.println(USER_ID);
			//System.out.println(Leave_Balance);
			if(Leave_Balance>NoOfDays)
			{PreparedStatement preparedStatement = conn.prepareStatement("insert into Leave_History(LEAVE_ID,EMP_ID,LEAVE_BALANCE,NO_OF_DAYS_APPLIED,DATE_FROM,Status) values(leaveID.nextval,?,?,?,?,'applied')");
			
			preparedStatement.setString(1, USER_ID);
			preparedStatement.setInt(2, Leave_Balance);
			preparedStatement.setInt(3, NoOfDays);
			preparedStatement.setDate(4, leaveFrom1);
			storedStatus=preparedStatement.executeUpdate();
			PreparedStatement preparedStatement2 = conn.prepareStatement("update Leave_History set DATE_TO = ? + ? where EMP_ID=?");
			preparedStatement2.setDate(1,leaveFrom1);
			preparedStatement2.setInt(2, NoOfDays);
			preparedStatement2.setString(3, USER_ID);
			//preparedStatement2.
			storedStatus=preparedStatement2.executeUpdate();}
			
			}
		catch(Exception e)
		{      log.error("Error in applyLeave() method");
			 throw new EmployeeException("Leave NOT DONE: "+e.getMessage());
		}
		
		return storedStatus;
	}
	
	

}
