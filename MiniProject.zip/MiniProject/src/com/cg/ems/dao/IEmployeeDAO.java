package com.cg.ems.dao;

import com.cg.ems.bean.EmployeeBean;

public interface IEmployeeDAO {
	
	public abstract int addEmployeeDetails(EmployeeBean ob);

}
