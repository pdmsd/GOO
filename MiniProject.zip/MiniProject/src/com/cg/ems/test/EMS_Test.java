/**
 * 
 *//*
package com.cg.ems.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.dao.EmployeeDAO;
import com.cg.ems.dao.IEmployeeDAO;
import com.cg.ems.exception.EmployeeException;

*//**
 * @author piydubey
 *
 *//*
public class EMS_Test {

	*//**
	 * Test method for {@link com.cg.ems.dao.EmployeeDAO#searchEmployees(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)}.
	 *//*
	@Test
	public void testSearchEmployees() {
		IEmployeeDAO employeeDao = new EmployeeDAO();
		EmployeeBean employee = new EmployeeBean();
		employee.setEmpID("EMP123");
		try {
			employeeDao.addEmployeeDetails(employee);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		;
		assert.equals(1,employeeDao.searchEmployees("EMP123"));
		
	}

}
*/