package com.cg.ems.bean;

public class EmployeeBean {
	private String UserID;
	private String UserName;
	private String UserPassword;
	private String UserType;
	
	private int DeptID;
	private String DeptName;
	
	private int EmpID;
	private String EmpFirstName;
	private String EmpLastName;
	private String EmpDOB;
	private String EmpDOJ;
	private int EmpDeptID;
	private String EmpGrade;
	private String EmpDesignation;
	private int EmpBasic;
	private String EmpGender;
	private String EmpMaritalStatus;
	private String EmpAddress;
	private long EmpContact;
	private int MgrID;
	
	private String GradeCode;
	private String Description;
	private int MaxSal;
	private int MinSal;
	
	private int LeaveID;
	private int LeaveBalance;
	private int NoOFDays;
	private String DateFrom;
	private String DateTo;
	private String Status;
	public String getUserID() {
		return UserID;
	}
	public void setUserID(String userID) {
		UserID = userID;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getUserPassword() {
		return UserPassword;
	}
	public void setUserPassword(String userPassword) {
		UserPassword = userPassword;
	}
	public String getUserType() {
		return UserType;
	}
	public void setUserType(String userType) {
		UserType = userType;
	}
	public int getDeptID() {
		return DeptID;
	}
	public void setDeptID(int deptID) {
		DeptID = deptID;
	}
	public String getDeptName() {
		return DeptName;
	}
	public void setDeptName(String deptName) {
		DeptName = deptName;
	}
	public int getEmpID() {
		return EmpID;
	}
	public void setEmpID(int empID) {
		EmpID = empID;
	}
	public String getEmpFirstName() {
		return EmpFirstName;
	}
	public void setEmpFirstName(String empFirstName) {
		EmpFirstName = empFirstName;
	}
	public String getEmpLastName() {
		return EmpLastName;
	}
	public void setEmpLastName(String empLastName) {
		EmpLastName = empLastName;
	}
	public String getEmpDOB() {
		return EmpDOB;
	}
	public void setEmpDOB(String empDOB) {
		EmpDOB = empDOB;
	}
	public String getEmpDOJ() {
		return EmpDOJ;
	}
	public void setEmpDOJ(String empDOJ) {
		EmpDOJ = empDOJ;
	}
	public int getEmpDeptID() {
		return EmpDeptID;
	}
	public void setEmpDeptID(int empDeptID) {
		EmpDeptID = empDeptID;
	}
	public String getEmpGrade() {
		return EmpGrade;
	}
	public void setEmpGrade(String empGrade) {
		EmpGrade = empGrade;
	}
	public String getEmpDesignation() {
		return EmpDesignation;
	}
	public void setEmpDesignation(String empDesignation) {
		EmpDesignation = empDesignation;
	}
	public int getEmpBasic() {
		return EmpBasic;
	}
	public void setEmpBasic(int empBasic) {
		EmpBasic = empBasic;
	}
	public String getEmpGender() {
		return EmpGender;
	}
	public void setEmpGender(String empGender) {
		EmpGender = empGender;
	}
	public String getEmpMaritalStatus() {
		return EmpMaritalStatus;
	}
	public void setEmpMaritalStatus(String empMaritalStatus) {
		EmpMaritalStatus = empMaritalStatus;
	}
	public String getEmpAddress() {
		return EmpAddress;
	}
	public void setEmpAddress(String empAddress) {
		EmpAddress = empAddress;
	}
	public long getEmpContact() {
		return EmpContact;
	}
	public void setEmpContact(long empContact) {
		EmpContact = empContact;
	}
	public int getMgrID() {
		return MgrID;
	}
	public void setMgrID(int mgrID) {
		MgrID = mgrID;
	}
	public String getGradeCode() {
		return GradeCode;
	}
	public void setGradeCode(String gradeCode) {
		GradeCode = gradeCode;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public int getMaxSal() {
		return MaxSal;
	}
	public void setMaxSal(int maxSal) {
		MaxSal = maxSal;
	}
	public int getMinSal() {
		return MinSal;
	}
	public void setMinSal(int minSal) {
		MinSal = minSal;
	}
	public int getLeaveID() {
		return LeaveID;
	}
	public void setLeaveID(int leaveID) {
		LeaveID = leaveID;
	}
	public int getLeaveBalance() {
		return LeaveBalance;
	}
	public void setLeaveBalance(int leaveBalance) {
		LeaveBalance = leaveBalance;
	}
	public int getNoOFDays() {
		return NoOFDays;
	}
	public void setNoOFDays(int noOFDays) {
		NoOFDays = noOFDays;
	}
	public String getDateFrom() {
		return DateFrom;
	}
	public void setDateFrom(String dateFrom) {
		DateFrom = dateFrom;
	}
	public String getDateTo() {
		return DateTo;
	}
	public void setDateTo(String dateTo) {
		DateTo = dateTo;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public EmployeeBean(String userID, String userName, String userPassword,
			String userType, int deptID, String deptName, int empID,
			String empFirstName, String empLastName, String empDOB,
			String empDOJ, int empDeptID, String empGrade,
			String empDesignation, int empBasic, String empGender,
			String empMaritalStatus, String empAddress, long empContact,
			int mgrID, String gradeCode, String description, int maxSal,
			int minSal, int leaveID, int leaveBalance, int noOFDays,
			String dateFrom, String dateTo, String status) {
		super();
		UserID = userID;
		UserName = userName;
		UserPassword = userPassword;
		UserType = userType;
		DeptID = deptID;
		DeptName = deptName;
		EmpID = empID;
		EmpFirstName = empFirstName;
		EmpLastName = empLastName;
		EmpDOB = empDOB;
		EmpDOJ = empDOJ;
		EmpDeptID = empDeptID;
		EmpGrade = empGrade;
		EmpDesignation = empDesignation;
		EmpBasic = empBasic;
		EmpGender = empGender;
		EmpMaritalStatus = empMaritalStatus;
		EmpAddress = empAddress;
		EmpContact = empContact;
		MgrID = mgrID;
		GradeCode = gradeCode;
		Description = description;
		MaxSal = maxSal;
		MinSal = minSal;
		LeaveID = leaveID;
		LeaveBalance = leaveBalance;
		NoOFDays = noOFDays;
		DateFrom = dateFrom;
		DateTo = dateTo;
		Status = status;
	}
	public EmployeeBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	
	
	

}
