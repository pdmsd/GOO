package com.cg.ems.service;

import com.cg.ems.bean.EmployeeBean;

public interface IEmployeeService {

	public abstract int addEmployeeDetails(EmployeeBean beanOB);
	
}
