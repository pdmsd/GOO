package com.cg.ems.service;

import java.sql.Date;
import java.util.ArrayList;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.dao.EmployeeDAO;
import com.cg.ems.dao.IEmployeeDAO;
import com.cg.ems.exception.EmployeeException;

public class EmployeeService implements IEmployeeService{
	
	IEmployeeDAO employeedao0 = new EmployeeDAO();
	IEmployeeDAO employeedao = new EmployeeDAO();
	IEmployeeDAO employeedao2 = new EmployeeDAO();
	IEmployeeDAO employeedao3 = new EmployeeDAO();
	IEmployeeDAO employeedao4 = new EmployeeDAO();
	IEmployeeDAO employeedao5 = new EmployeeDAO();
	IEmployeeDAO employeedao6 = new EmployeeDAO();

	@Override
	public int addEmployeeDetails(EmployeeBean beanOB) throws EmployeeException{
		
		return employeedao.addEmployeeDetails(beanOB);
		
	}
	@Override
	public EmployeeBean displayEmployeeDetailsAdmin(String searchID) throws EmployeeException
	{
		
		return employeedao3.displayEmployeeDetailsAdmin(searchID);
	}
	@Override
	public EmployeeBean displayEmployeeDetailsUser(String searchID)
			throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}
    public ArrayList<EmployeeBean> searchEmployees(String searchID, String searchFName, String searchLName, String searchDept, String searchGrade, String searchMStatus) throws EmployeeException
    {
    	return employeedao4.searchEmployees(searchID, searchFName, searchLName, searchDept, searchGrade, searchMStatus);
    }
	public ArrayList<EmployeeBean> displayAll() throws EmployeeException {
		// TODO Auto-generated method stub
		return employeedao3.displayAll();
	}
	public EmployeeBean getaccess(String UserName, String password) throws EmployeeException{
		// TODO Auto-generated method stub
		return employeedao0.getaccess(UserName, password);
	}
	public int updateEmployees(EmployeeBean beanOB,int value2) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeedao2.updateEmployees(beanOB, value2);
	}
	
	public int EmpORMgr(String UserName) throws EmployeeException{
		return employeedao5.EmpORMgr(UserName);
		
		
		// TODO Auto-generated method stub
		
	}
	public int applyLeave(String UserName, Date leaveFrom1,int NoOfDays) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeedao6.applyLeave(UserName, leaveFrom1, NoOfDays);
	}
}
