package com.cg.ems.service;

import com.cg.ems.bean.EmployeeBean;
import com.cg.ems.dao.EmployeeDAO;

public class EmployeeService implements IEmployeeService{
	
	EmployeeDAO employeedao = new EmployeeDAO();

	@Override
	public int addEmployeeDetails(EmployeeBean beanOB) {
		
		return employeedao.addEmployeeDetails(beanOB);
		
	}
	

}
